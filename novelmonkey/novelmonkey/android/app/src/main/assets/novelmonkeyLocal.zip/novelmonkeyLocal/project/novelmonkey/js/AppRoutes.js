let _localH5Name = "project/novelmonkey/local/";
var LocalRoutes = {
    //注册页面
    regist_page:_localH5Name + "login/regist.html",

    //忘记密码
    forget_pwd_page:_localH5Name + "login/forget_pwd.html",

    //验证码登录
    sms_login_page:_localH5Name + "login/sms_login.html",

    //选择性别
    select_sex_page:_localH5Name + "login/select_sex.html",
}