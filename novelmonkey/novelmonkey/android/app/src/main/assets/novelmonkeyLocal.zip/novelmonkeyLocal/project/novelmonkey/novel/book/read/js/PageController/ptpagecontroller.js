/**
 * 设置翻页控制器
 */
var ptPageControl;//章节翻页的控制器
var autoReadTimer;//自动翻页的计时器
function setPTController() {
    if (autoReadTimer != null) {
        clearInterval(autoReadTimer);
        autoReadTimer = null;
    }

    var readBgView = document.getElementById("chapterPageBgView");
    var chapter0 = bodyData.chapterInfos.lastChapter;// setChapterEleAndReturnChapterInfo(text, "chapter0", 1);
    var chapter1 = bodyData.chapterInfos.currentChapter;// setChapterEleAndReturnChapterInfo(text, "chapter1", 2);
    var chapter2 = bodyData.chapterInfos.nextChapter;// setChapterEleAndReturnChapterInfo(text, "chapter2", 3);
    function loadLastFunc(isNeed) {
        //要到上一章了
        prepareLoadChapterInfor(true, isNeed);
    }

    function loadNextFunc(isNeed) {
        //要到上一章了
        prepareLoadChapterInfor(false, isNeed);
    }

    if (chapter1.currentPageIndex == null)chapter1.currentPageIndex = 1;
    if (chapter1.currentPageIndex > chapter1.pages.length) {
        chapter1.currentPageIndex = chapter1.pages.length;
    }

    //类型对应
    switch (bodyData.readMenu.turnPageStyleSelectId) {
        case -1:{
            ptPageControl = new FreeScroll(readBgView.clientHeight, chapter0, chapter1, chapter2, loadLastFunc, loadNextFunc);
        }
            break;
        case 0: {
            ptPageControl = new PTHorOverControll(readBgView.clientWidth, chapter0, chapter1, chapter2, loadLastFunc, loadNextFunc);
        }
            break;
        case 1: {
            ptPageControl = new PTHorPlainControll(readBgView.clientWidth, chapter0, chapter1, chapter2, loadLastFunc, loadNextFunc);
        }
            break;
        case 2: {
            ptPageControl = new PTVerPlainControll(readBgView.clientHeight, chapter0, chapter1, chapter2, loadLastFunc, loadNextFunc);
        }
            break;
        case 3: {
            ptPageControl = new PTLikeBookControll(chapter0, chapter1, chapter2, loadLastFunc, loadNextFunc);
        }
            break;
        case 4: {
            ptPageControl = new PTNoAnimControll(chapter0, chapter1, chapter2, loadLastFunc, loadNextFunc);
        }
            break;
    }

    llApi.showMask(0);


    loadLastFunc(false);
    loadNextFunc(false);

    return ptPageControl;
}

/**
 * 清楚控制器信息
 */
function clearController() {

    //删除定时器
    if (autoReadTimer != null) {
        clearInterval(autoReadTimer);
        autoReadTimer = null;
    }
    //删除翻页控制器
    ptPageControl = null;
}



/**
 * 翻到对应章节
 * @param chapterId 章节数组中的index
 */
function turnToChapter(chapterIndex,pageIndex) {
    var chapterList = bodyData.chapterListInfo.chapterTBList;
    var chapterInfo = chapterList[chapterIndex];
    getChapterText(bodyData.bookDetail.bookId, chapterInfo, true,false, function (resp) {
        //当前章节显示的标签id
        var chapterId = "chapter1";
        if (bodyData.chapterInfos.currentChapter != null) chapterId = bodyData.chapterInfos.currentChapter.chapterId;

        bodyData.chapterInfos.currentChapter = setChapterEleAndReturnChapterInfo(resp, chapterId, chapterIndex);
        bodyData.chapterInfos.currentChapter.currentPageIndex = pageIndex == null ? 1 : pageIndex;//设置当前页码
        if (ptPageControl) {
            ptPageControl.setChapterInfo(1, bodyData.chapterInfos.currentChapter);
        } else {
            setPTController();
        }
        llApi.showMask(0);


        //保存阅读进度
        saveReadProgress();


        //刷新用户信息（钱包相关）
        llApi.refreshUserInfoData(function (resp) {
            if (resp != null){
                bodyData.userDetail = resp;
            }
        });

        prepareLoadChapterInfor(true, false);
        prepareLoadChapterInfor(false, false);
    });

}


/**
 * 获取章节内容
 * @param bookId  书籍id
 * @param chapterId 章节id
 * @param downloadUrl 下载链接
 * @param isShowMask 是否显示蒙版
 * @param isOnlyPrepare 是否只是预加载，预加载不返回给js数据
 * @param func 回调，参数为章节内容
 */
function getChapterText(bookId, chapterInfo, isShowMask,isOnlyPrepare, func) {
    // func(txt);
    // return;

    var info = chapterInfo;
    llApi.getChapterText(bookId, chapterInfo.chapterId,chapterInfo.chapterDownloadUrl, isShowMask,isOnlyPrepare, function (response) {
        if (response.code == 0) {
            if (info.chapterStatus == 2){

                info.chapterStatus = 1;
                llApi.loge(info.chapterId);
                // for (let i = 0; i < bodyData.chapterListInfo.chapterTBList.length; i++) {
                //     var item = bodyData.chapterListInfo.chapterTBList[i];
                //     if (item.chapterId == chapterInfo.chapterId) {
                //         item.chapterStatus = 1;
                bodyData.chapterListInfo = jsonToModel(jsonToStr(bodyData.chapterListInfo));
                //     }
                // }

            }
            func(response.data);
        }else if(response.code == -10){
            llApi.monkey_analysis("reader_locked_view");
            bodyData.chapterBuyDialogInfo.chapterInfo = chapterInfo;
            bodyData.showChapterPayDialog();
        }else if(isOnlyPrepare == false){
            toast(response.msg);
        }
    });
}


/**
 * 设置章节内容并返回章节信息
 * @param chapterText 文章内容
 * @param chapterViewId 文章根节点id
 * @param chapterIndex 章节的编码
 */
function setChapterEleAndReturnChapterInfo(chapterText, chapterViewId, chapterIndex) {

    //如果是自由滚动则调用下面方法
    if (bodyData.readMenu.turnPageStyleSelectId == -1){
        return _setFreeChapterInfo(chapterText,chapterIndex)
    }


    //如果是动画翻页则调用下面

    var bgColor = bodyData.getBgColor;

    //每一页的高度
    var onePageHeight = bodyData.textBgHeight;




    /**
     * 获取某一页的html信息
     * @param chapterId 文章标签节点id
     * @param pageBgId page页面根节点id
     * @param pageTextId page页面存储文字的节点id
     * @param innerHtml page页面存储的文本内容
     * @param offset page页面展示文本信息的位置
     */
    function getOnePageInnerHtml(chapterId, pageBgId, pageTextId, pageIndex, innerHtml, offset) {
        var html = "<div id='" + pageBgId + "' class='page_bg' style='background-color: " + bgColor + "'>" +
            "<div class='chapter_body' style='height:" + onePageHeight + "px'>" +
            "<div class='chapter_text' id='" + chapterId + "_page_" + pageIndex + "' style='top:" + offset + "px;'>" + innerHtml  + "</div>" +
            "</div>" +
            "</div>";
        return html;
    }


    /**
     * 获取初始化的章节信息
     * @param chapterId 章节根节点id
     * @param chapterText 章节文本
     * @param chapterIndex 章节目录中的index
     * @return {{text: *, pages: Array}}
     */
    function getEmptyChapterInfo(chapterId, chapterText, chapterIndex) {
        return {
            chapterId: chapterId,//章节View 的 标签id
            text: chapterText,//章节文本内容
            chapterIndex: chapterIndex,//当前章节在章节列表中的位置
            currentPageIndex: 0,//当前展示的页面位置
            pages: [],//页码信息
        };
    }

    /**
     * 创建页码标签及信息
     * @param pageHtml
     */
    function createPageAndInfo(pageHtml,topOffSet){
        //添加page信息
        var pageItemInfo = {
            pageTextId: chapterViewId + "_page_" + chapterInfo.pages.length,//页面的文本存储的标签ID
            pageBgId: chapterViewId + "_page_bg_" + chapterInfo.pages.length,//page页面的背景标签
            offset: -topOffSet,
            isHaveText: true,
            text:pageHtml,
        };
        chapterInfo.pages.push(pageItemInfo);

        //章节内容添加 页码内容
        var htmlStr = getOnePageInnerHtml(
            chapterViewId,
            pageItemInfo.pageBgId,
            pageItemInfo.pageTextId,
            chapterInfo.pages.length,
            pageHtml,
            pageItemInfo.offset
        );

        $("#" + chapterViewId).append(htmlStr);

        //将章节内容重置
        // testView.innerHTML = "";
    }

    //测试文字内容空间大小的控件
    let testView = document.getElementById("testTextView");


    //设置章节信息
    let chapterInfo = getEmptyChapterInfo(chapterViewId, chapterText, chapterIndex);


    //章节根节点
    var chapterEle = document.getElementById(chapterViewId);
    if (chapterEle != null){
        //先删除
        chapterEle.remove();
    }
    //然后重新添加
    chapterEle = document.createElement("div");
    chapterEle.className = 'chapter_bg';
    chapterEle.style.top = '0px';
    chapterEle.style.bottom = '0px';
    chapterEle.id = chapterViewId;
    document.getElementById("chapterPageBgView").appendChild(chapterEle);



    //html文本信息
    var text = chapterText;
    var list = text.split("\n");

    var currentPageTextListCount = 0;//当前页面段落数量

    var lastHeight = 0;//加载上一个段落时的高度
    var needRemoveHeight = 0;//下一章节需要删除的高度
    var textList = "";//每页的文本内容
    let chapterHtmlText = "";//章节内的html内容
    for (var i = 0; i < list.length; i++) {
        var str = list[i];
        textList += "<p>" + str + "</p>";
        currentPageTextListCount++;

        testView.innerHTML = textList;
        //这是这个章节的文本高度
        var height = testView.clientHeight;
        var isAddPage = false;//是否当前数据做为一个页面添加
        if (height < onePageHeight + needRemoveHeight - 2){
            if (i == list.length - 1){
                isAddPage = true;
            }else{
                //说明还没填满
                lastHeight = height;
            }
        } else{
            //说明当前内容高于需要的内容高度了
            if (currentPageTextListCount == 1){
                //说明一段落已经超出一屏了
                while (height > needRemoveHeight + onePageHeight) {
                    createPageAndInfo(textList,needRemoveHeight);

                    //下一章节需要偏移的大小
                    needRemoveHeight = onePageHeight + needRemoveHeight;
                }
                lastHeight = height;

            } else{
                isAddPage = true;
                i--;
            }
        }

        if (isAddPage){
            createPageAndInfo(textList,needRemoveHeight);

            //下一章节需要偏移的大小
            needRemoveHeight = onePageHeight + needRemoveHeight - lastHeight;

            currentPageTextListCount = 0;

            textList = "";
        }
    }

    // chapterEle.innerHTML = chapterHtmlText;

    if (chapterInfo.pages.length > 0 && bodyData.chapterListInfo.chapterTBList){
        var pageId = chapterInfo.pages[chapterInfo.pages.length - 1].pageBgId;
        var btmBtnEle = "<div class='float_clear page_scroll_btm_btn_bg'>"
            // + "<div class='free_btm_btn' onclick='bodyData.lastPageClick();event.stopPropagation();'>← LAST</div>"
            + "<div class='next_chapter_btn' onclick='bodyData.goNextChapter(false);event.stopPropagation();'>Next chapter</div>";

        + "</div>";
        $("#" + pageId).append(btmBtnEle);
    }

    // testView.innerHTML = "";

    return chapterInfo;
}
function _setFreeChapterInfo(chapterText, chapterIndex) {
    //如果是动画翻页则调用下面
    var bgColor = bodyData.getBgColor;


    /**
     * 获取初始化的章节信息
     * @param chapterId 章节根节点id
     * @param chapterText 章节文本
     * @param chapterIndex 章节目录中的index
     * @return {{text: *, pages: Array}}
     */
    function getEmptyChapterInfo(chapterText, chapterIndex) {
        return {
            text: chapterText,//章节文本内容
            chapterId:"chapter1",
            chapterIndex: chapterIndex,//当前章节在章节列表中的位置
            currentPageIndex: 1,//当前展示的页面位置
            pages: [],//页码信息
        };
    }


    //html文本信息
    var text = chapterText;
    var list = text.split("\n");
    var textList = "";
    for (let i = 0; i < list.length; i++) {
        var str = list[i];
        textList += "<p>" + str + "</p>";
    }

    let testView = document.getElementById("testTextView");
    testView.innerHTML = textList;
    //这是这个章节的文本高度
    var height = testView.clientHeight;


    //总的页码数
    var pageCount = Math.floor(height / bodyData.textBgHeight);


    //设置章节信息
    let chapterInfo = getEmptyChapterInfo(chapterText, chapterIndex);
    for (let i = 0; i < pageCount; i++) {
        //添加page信息
        var pageItemInfo = {};
        chapterInfo.pages.push(pageItemInfo);
    }

    //章节根节点
    var chapterEle = document.getElementById(chapterInfo.chapterId);
    if (chapterEle != null){
        //先删除
        chapterEle.remove();
    }
    //然后重新添加
    chapterEle = document.createElement("div");
    chapterEle.className = 'free_scroll_chapter_bg';
    chapterEle.id = chapterInfo.chapterId;
    document.getElementById("chapterPageBgView").appendChild(chapterEle);


    chapterEle.innerHTML = "<div id='free_scroll_body_id' class='free_scroll_body'>"
        + textList
        + "<div class='float_clear free_btm_btn_bg'>"
        + "<div class='free_btm_btn' onclick='bodyData.goLastChapter();event.stopPropagation();'>← LAST</div>"
        + "<div class='free_btm_btn' onclick='bodyData.goNextChapter(false);event.stopPropagation();'>NEXT →</div>"
        + "</div>"
        + "</div>";

    testView.innerHTML = "";

    return chapterInfo;
}

/**
 * 预加载章节信息
 * @param isLast 是否是上一章
 * @param isNeed 是否是现在必须要展示的
 */
function prepareLoadChapterInfor(isLast, isNeed) {
    //1、获取当前页信息
    var currentChapterInfo = ptPageControl.getChapterInfo(1);

    if (isLast) {
        //1、获取当前页信息
        if (currentChapterInfo.currentChapterIndex > 0) {
            var lastChapterInfo = bodyData.chapterListInfo.chapterTBList[currentChapterInfo.currentChapterIndex - 1];
            if (lastChapterInfo.chapterStatus == 2 && bodyData.chapterBuyDialogInfo.isAuOpenNextChapter == false){
                //如果章节需要付费，并且用户不自动支付章节费用  则返回
                return;
            }

            //判断是否有上一页
            if (isNeed) {
                llApi.showMask(1);
            }
            //这不是第一章,获取上一张信息
            getChapterText(bodyData.bookDetail.bookId, lastChapterInfo, isNeed,false, function (text) {
                llApi.showMask(0);
                var chapterIdNum = parseInt(currentChapterInfo.chapterId.split("chapter")[1]) - 1;
                if (chapterIdNum == -1) chapterIdNum = 2;
                var chapter = setChapterEleAndReturnChapterInfo(text, "chapter" + chapterIdNum, currentChapterInfo.currentChapterIndex - 1);
                ptPageControl.setChapterInfo(0, chapter);
                bodyData.chapterInfos.lastChapter = chapter;
                if (isNeed) {
                    bodyData.lastPageClick();
                }
            });
        } else {
            //这是第一章
            if (isNeed) {
                // toast("这已经是第一章了！");
            }
        }
    } else {


        //判断是否有下一章
        if (currentChapterInfo.currentChapterIndex < bodyData.chapterListInfo.chapterTBList.length - 1) {
            //下一章节信息
            var nextChapterInfo = bodyData.chapterListInfo.chapterTBList[currentChapterInfo.currentChapterIndex + 1];
            if (nextChapterInfo.chapterStatus == 2 && bodyData.chapterBuyDialogInfo.isAuOpenNextChapter == false){
                //如果章节需要付费，并且用户不自动支付章节费用  则返回
                return;
            }
            //还有下一章
            getChapterText(bodyData.bookDetail.bookId, nextChapterInfo, isNeed, false, function (text) {
                var chapterIdNum = parseInt(currentChapterInfo.chapterId.split("chapter")[1]) + 1;
                if (chapterIdNum == 3) chapterIdNum = 0;
                var chapter = setChapterEleAndReturnChapterInfo(text, "chapter" + chapterIdNum, currentChapterInfo.currentChapterIndex + 1);
                ptPageControl.setChapterInfo(2, chapter);
                bodyData.chapterInfos.nextChapter = chapter;
                if (isNeed) {
                    bodyData.nextPageClick();
                }
            });

        } else {
            //这是最后一章
            if (isNeed) {
                // toast("这已经是最新章节了！");
            }
        }
    }
}

