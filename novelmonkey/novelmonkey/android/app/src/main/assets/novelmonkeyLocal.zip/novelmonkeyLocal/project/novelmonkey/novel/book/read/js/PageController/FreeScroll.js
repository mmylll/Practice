/**
 * 水平方向平滑
 * @param chapter0 上一章节信息
 * @param chapter1 当前章节信息
 * @param chapter2 下一章节信息
 * @param needGoNextPageCallBack 需要上翻时调用，参数bool值，是否急需
 * @param needGoPreviousCallBack 需要下翻时调用，参数bool值，是否急需
 */
function FreeScroll(pageHeight, chapter0, chapter1, chapter2, needGoPreviousCallBack, needGoNextPageCallBack) {
    var _lastChapterInfo = chapter0;
    var _currentChapterInfo = chapter1;
    var _nextChapterInfo = chapter2;
    var bgView = document.getElementById("chapter1");

    _initChapterInfos();


    //到上一页面
    this.goLast = function () {
        if (_currentChapterInfo.chapterIndex > 0) {
            bodyData.goLastChapter();
        }
    };

    //到下一页面
    this.goNext = function () {
        if (_currentChapterInfo.chapterIndex < bodyData.chapterListInfo.chapterTBList.length - 1) {
            bodyData.goNextChapter();
        }
    };


    //设置页码到哪个页面
    this.setCurrentPage = function (pageIndex) {
        _currentChapterInfo.currentPageIndex = pageIndex;
        bgView.scrollTop = (pageIndex - 1) * pageHeight + "px";
    };


    /**
     * 获取数据
     * @param index
     * @return {*}
     */
    this.getChapterInfo = function (index) {
        switch (index) {
            case 0: {
                return _lastChapterInfo;
            }
            case 1: {
                return _currentChapterInfo;
            }
            case 2: {
                return _nextChapterInfo;
            }
        }
    };
    /**
     * 获取数据
     * @param index
     * @return {*}
     */
    this.setChapterInfo = function (index, info) {
        switch (index) {
            case 0: {
                _lastChapterInfo = info;
            }
                break;
            case 1: {
                _currentChapterInfo = info;
            }
                break;
            case 2: {
                _nextChapterInfo = info;
            }
                break;
        }
        if (info) {
            info.currentPageIndex = index == 0 ? info.pages.length : (index == 2 ? 1 : info.currentPageIndex);
            if (index == 1) {
                _initChapterInfos();
            }
        }
    };



    var lastProgress = 0.195;
    /**
     * 对象初始化
     * @private
     */
    function _initChapterInfos() {
        var bgView = document.getElementById("chapter1");

        //   这里边可以写一些逻辑，比如偶数行一个一个的置顶，不如状态等于0的一个一个的置顶！
        if (_currentChapterInfo.currentScrolTop != null) {
            bgView.scrollTop = _currentChapterInfo.currentScrolTop;
        } else {
            var scrolTop = pageHeight * (_currentChapterInfo.currentPageIndex - 1);
            bgView.scrollTop = scrolTop;
        }


        bgView.onscroll = function () {
            //scrollTop就是触发滚轮事件时滚轮的高度
            var scrollTop = bgView.scrollTop;


            _currentChapterInfo.currentScrolTop = scrollTop;

            var pageIndex = parseInt(scrollTop / pageHeight) + 1;


            if (_currentChapterInfo != null) {
                _currentChapterInfo.currentPageIndex = pageIndex;
            }

            /**
             * 阅读进度统计
             * @type {number}
             */
            var progress = bgView.scrollTop * 1.0 / bgView.scrollHeight;
            if (progress > lastProgress && lastProgress < 0.95) {
                progress = lastProgress + 0.05;
                llApi.monkey_analysis("chapter_read_progress",
                    {
                        book_id: bodyData.bookDetail.bookId,
                        chapter_id: bodyData.chapterListInfo.chapterTBList[_currentChapterInfo.chapterIndex].chapterId,
                        progress: progress
                    });
                lastProgress += 0.2;
            }
        }
    }
}