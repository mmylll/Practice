(function () {
    let url = window.location.href;
    let arr = url.split("project");
    let leftPath = "";
    if (arr.length == 2){
        //说明这是项目的路径
        leftPath = arr[0];
    } else{
        arr = url.split("base");
        //说明这是基础类的路径
        leftPath = arr[0];
    }
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/base64.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/jquery-3.3.1.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/Vue.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLTool.js?v=2" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLToast.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLdialog.js?v=1" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLApi.js?v=1" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLNv.js?v=1" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLNetUtils.js?v=1" + "'></script>");
    document.write("<link rel='stylesheet' href='" + leftPath + "base/css/base/ll-base-css.css'>");
    document.write("<link rel='stylesheet' href='" + leftPath + "base/css/base/ll_project_base.css?v=1'>");
})();



/**
 * 获取基类文件绝对路径
 * @param jsApi
 */
function getBaseFile(filePath) {
    let url = window.location.href;
    let leftPath = url.split("project")[0] + 'base/' + filePath;

    return leftPath;
}
/**
 * 加载基类里面的文件
 * @param filePath 在base里面的路径
 */
function loadBaseFile(filePath) {

    document.write("<script language=javascript src='" + getBaseFile(filePath) + "'></script>");
}



/**
 * 获取工程文件绝对路径
 * @param jsApi
 */
function getProjectFile(filePath) {
    let url = window.location.href;
    let leftPath = url.split("project")[0];
    let rightPath = url.split("project/")[1];
    let projectName = rightPath.split("/")[0];
    return leftPath + "project/" + projectName + "/" + filePath;
}
/**
 * 加载基类里面的文件
 * @param filePath 在base里面的路径
 */
function loadProjectFile(filePath) {
    document.write("<script language=javascript src='" + getProjectFile(filePath) + "'></script>");
}
