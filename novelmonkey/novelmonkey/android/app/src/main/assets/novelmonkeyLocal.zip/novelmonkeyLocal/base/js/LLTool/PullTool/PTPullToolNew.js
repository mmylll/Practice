var getDefaultOptions = function () {
    return {
        headerMaxHeigth: 150,//header最大高度
        headerRefreshHeight: 60,//header刷新组件高度
        headerHtml: ["", "", "", ""],//顶部刷新控件   刷新前，刷新中，刷新结束


        footerMaxHeight: 150,//底部最大下拉距离
        footerRefreshHeight: 60,//底部刷新时保持的高度
        footerHtml: ["", "", "", ""],//底部刷新控件   刷新前，刷新中，刷新结束

    };
}

/**
 *
 * @param parentId
 * @param scrollBodyId
 * @param onRefeshCall
 * @param onPullCall
 * @param options 配置参数  见 getDefaultOptions
 * @constructor
 */
function PTRefresh(parentId, scrollBodyId, onRefreshCall, onPullCall, options) {
    var self = this;

    var parentArea = document.getElementById(parentId);//接收触摸的元素
    var scrollBody = document.getElementById(scrollBodyId);//滚动的主体区域


    var _refreshHeader = null;//刷新头部  背景标签
    var _headerStatus = 0;//header状态 0：默认状态，/*1在下拉中*/，2加载中，3加载完成，4加载失败


    var _refreshFooter = null;//刷新底部 背景标签
    var _footerStatus = 0;//footer状态 0：默认状态，/*1在上拉中*/，2加载中，3加载完成，4加载失败
    var startPos = {x: 0, y: 0};//开始的位置

    if (options == null) {
        options = getDefaultOptions();
    }


    setHeaderAndFooterInfo();

    //滑动开始
    var start = function (event) {
        if (_headerStatus != 0 || _footerStatus != 0) return;

        var touch = event.targetTouches[0];//第一个手指触摸点
        startPos = {x: touch.pageX, y: touch.pageY};//开始的位置
        console.log("start");
    };
    //移动
    var move = function (event) {
        console.log("move >> " + _headerStatus + " > " + _footerStatus);
        if (_headerStatus != 0 || _footerStatus != 0) return;
        console.log("move");

        //当屏幕有多个touch或者页面被缩放过，就不执行move操作
        if (event.targetTouches.length > 1 || event.scale && event.scale !== 1) return;
        var touch = event.targetTouches[0];//第一个手指触摸点
        var movePos = {
            x: touch.pageX - startPos.x,
            y: touch.pageY - startPos.y
        };//手指在屏幕移动的位置


        var isTopRefreshShow = false;

        //先处理顶部
        var topAddHeight = movePos.y / 2; //顶部滚动大小
        if (parentArea.scrollTop <= 0) {
            if (onRefreshCall == null) {
                _refreshHeader.style.height = "0px";
            } else if (_refreshHeader.clientHeight + topAddHeight > options.headerMaxHeight) {
                _refreshHeader.style.height = options.headerMaxHeight + "px";
            } else {
                if (_refreshHeader.clientHeight + topAddHeight < 0) {
                    //如果顶部控件加上添加的高度小于0，重置为0
                    topAddHeight = -_refreshHeader.clientHeight;
                }
                _refreshHeader.style.height = _refreshHeader.clientHeight + topAddHeight + "px";
            }
            isTopRefreshShow = _refreshHeader.clientHeight > 0;
        }


        //再处理底部
        if (isTopRefreshShow) {
            if (_refreshFooter.clientHeight > 0){
                _refreshFooter.clientHeight = 0;
            }
        } else {

            if (_refreshFooter.offsetTop - parentArea.clientHeight - 1 <= parentArea.scrollTop){
                console.log(parentArea.clientHeight + " > " + parentArea.scrollTop + " > " + parentArea.scrollHeight);

                var btmAddHeight = -movePos.y; //底部添加高度
                if (onPullCall == null) {
                    _refreshFooter.style.height = "0px";
                } else if (_refreshFooter.clientHeight + btmAddHeight > options.footerMaxHeight) {
                    _refreshFooter.style.height = options.footerMaxHeight + "px";
                } else {
                    if (_refreshFooter.clientHeight + btmAddHeight < 0) {
                        //如果底部控件加上添加的高度小于0，重置为0
                        btmAddHeight = -_refreshFooter.clientHeight;
                    }
                    _refreshFooter.style.height = _refreshFooter.clientHeight + btmAddHeight + "px";
                }
                var scrollTop = parentArea.scrollHeight - parentArea.clientHeight;
                console.log(scrollTop);
                if (scrollTop < 0)scrollTop = 0;
                parentArea.scrollTop = scrollTop;
            }


        }


        //重置上一次的坐标点
        startPos.x = touch.pageX;
        startPos.y = touch.pageY;

    };
    //滑动释放
    var end = function (event) {
        //判断是否下拉刷新
        if (_refreshHeader.clientHeight >= options.headerRefreshHeight) {
            //是
            self.setHeaderStatus(2);
        } else if (_refreshHeader.clientHeight > 0) {
            //否
            self.setHeaderStatus(0);
        }

        //判断是否上拉加载
        if (parentArea.scrollHeight <= parentArea.clientHeight + parentArea.scrollTop){
            if (_refreshFooter.clientHeight > options.footerRefreshHeight) {
                //是
                self.setFooterStatus(2);
            } else if (_refreshFooter.clientHeight > 0) {
                //否
                self.setFooterStatus(0);
            }
        } else{
            self.setFooterStatus(0);
        }


    };

    //添加滚动监听事件
    var isTrue = true;
    parentArea.addEventListener("touchstart", start, isTrue);
    parentArea.addEventListener("touchmove", move, isTrue);
    parentArea.addEventListener("touchend", end, isTrue);


    this.setHeaderStatus = function (headerStatus) {
        _headerStatus = headerStatus;


        //0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
        switch (_headerStatus) {
            case 0: {//默认状态
                //将顶部刷新收回
                $("#" + _refreshHeader.id).animate({
                    height: "0px"
                }, 200, function () {
                    _headerStatus = 0;
                });
                _setHeaderStateElementHtml(0);
            }
                break;
            case 1: {//在下拉中

            }
                break;
            case 2: {//加载中
                _setHeaderStateElementHtml(1);
                $("#" + _refreshHeader.id).animate({
                    height: options.headerRefreshHeight + "px"
                }, 200);
                if (onRefreshCall != null) {
                    onRefreshCall();
                }
            }
                break;
            case 3: {//加载中
                _setHeaderStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshHeader.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _headerStatus = 0;
                        _setHeaderStateElementHtml(0);
                    });
                }, 300);
            }
                break;
            case 4: {//加载中
                _setHeaderStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshHeader.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _headerStatus = 0;
                        _setHeaderStateElementHtml(0);
                    });
                }, 300);

            }
                break;
        }
    }

    this.setFooterStatus = function (footStatus) {
        _footerStatus = footStatus;

        //0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
        switch (_footerStatus) {
            case 0: {//默认状态
                //将顶部刷新收回
                $("#" + _refreshFooter.id).animate({
                    height: "0px"
                }, 200, function () {
                    _footerStatus = 0;
                });
                _setFooterStateElementHtml(0);
            }
                break;
            case 1: {//在下拉中

            }
                break;
            case 2: {//加载中
                _setFooterStateElementHtml(1);
                $("#" + _refreshFooter.id).animate({
                    height: options.headerRefreshHeight + "px"
                }, 200);
                if (onPullCall != null) {
                    onPullCall();
                }
            }
                break;
            case 3: {//加载完成
                _setFooterStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshFooter.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _footerStatus = 0;
                        _setFooterStateElementHtml(0);
                    });
                }, 300);
            }
                break;
            case 4: {//加载中
                _setFooterStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshFooter.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _footerStatus = 0;
                        _setFooterStateElementHtml(0);
                    });
                }, 300);

            }
                break;
        }
    }

    this.autoRefresh = function () {
        if (_headerStatus == 0 && _footerStatus == 0) {
            self.setHeaderStatus(2);
        }
    };
    this.autoLoadMore = function () {
        if (_headerStatus == 0 && _footerStatus == 0) {
            self.setFooterStatus(2);
        }
    }
    this.endRefreshOrPull = function () {
        if (_headerStatus != 0){
            self.setHeaderStatus(3);
        }

        if (_footerStatus != 0){
            self.setFooterStatus(3);
        }
    };

    /**
     * 设置头部跟底部的标签指示器
     */
    function setHeaderAndFooterInfo() {

        var headerHtml = "<div id='refreshHeader' style='position: relative;text-align: center;overflow: hidden;width: 100%;height: 0px;z-index: 1000;'> </div>";
        $("#" + parentId).prepend(headerHtml);


        var footerHtml = "<div id=\"refreshFooter\" style='position: relative;text-align: center;overflow: hidden;width: 100%;height: 0px;z-index: 1000;'></div>";
        $("#" + parentId).append(footerHtml);

        _refreshHeader = document.getElementById("refreshHeader");
        _refreshFooter = document.getElementById("refreshFooter");


        _setHeaderStateElementHtml(0);
        _setFooterStateElementHtml(0)
    }

    // 0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
    function _setHeaderStateElementHtml(status) {
        let localUrl = window.location.href;
        var imgPath = localUrl.split("project")[0] + "base/imgs/";
        switch (status) {
            case 0: {
                if (options.headerHtml[0] != null && options.headerHtml[0].length > 0) {
                    _refreshHeader.innerHTML = options.headerHtml[0];
                } else {
                    _refreshHeader.innerHTML = "<div id='refreshHeader0' style='position: absolute;bottom: 0px;left: 0px;right: 0px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_down.png'><span>放开我，我要刷新</span>\n" +
                        "</div>";
                }
            }
                break;
            case 1: {
                if (options.headerHtml[1] != null && options.headerHtml[1].length > 0) {
                    _refreshHeader.innerHTML = options.headerHtml[1];
                } else {
                    _refreshHeader.innerHTML = "<div id='refreshHeader1' style='position: absolute;bottom: 0px;left: 0px;right: 0px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter\">\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "loading.gif'><span>刷新中...</span>\n" +
                        "</div>";
                }
            }
                break;
            case 2: {
                if (onRefreshCall == null) {
                    self.setHeaderStatus(0);
                    return;
                }
                if (options.headerHtml[2] != null && options.headerHtml[2].length > 0) {
                    _refreshHeader.innerHTML = options.headerHtml[2];
                } else {
                    _refreshHeader.innerHTML = "<div id='refreshHeader2' style='position: absolute;bottom: 0px;left: 0px;right: 0px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>刷新完成</span>\n" +
                        "</div>";
                }
            }
                break;
            case 3: {
                if (options.headerHtml[3] != null && options.headerHtml[3].length > 0) {
                    _refreshHeader.innerHTML = options.headerHtml[3];
                } else {
                    _refreshHeader.innerHTML = "<div id='refreshHeader2' style='position: absolute;bottom: 0px;left: 0px;right: 0px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>刷新完成</span>\n" +
                        "</div>";
                }
            }
                break;
        }
    }

// 0：默认状态，1加载中，2加载完成，3加载失败
    function _setFooterStateElementHtml(status) {
        let localUrl = window.location.href;
        var imgPath = localUrl.split("project")[0] + "base/imgs/";
        switch (status) {
            case 0: {
                if (options.footerHtml[0] != null && options.footerHtml[0].length > 0) {
                    _refreshFooter.innerHTML = options.footerHtml[0];
                } else {
                    _refreshFooter.innerHTML = "<div id='refreshFooter0' style='height: " + options.footerRefreshHeight + "px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_down.png'><span>放开我，我要加载</span>\n" +
                        "</div>";
                }
            }
                break;
            case 1: {
                if (options.footerHtml[1] != null && options.footerHtml[1].length > 0) {
                    _refreshFooter.innerHTML = options.footerHtml[1];
                } else {
                    _refreshFooter.innerHTML = "<div id='refreshFooter1' style='height: " + options.footerRefreshHeight + "px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "loading.gif'><span>加载中...</span>\n" +
                        "</div>";
                }
            }
                break;
            case 2: {
                if (onPullCall == null) {
                    self.setFooterStatus(0);
                    return;
                }
                if (options.headerHtml[2] != null && options.headerHtml[2].length > 0) {
                    _refreshFooter.innerHTML = options.headerHtml[2];
                } else {
                    _refreshFooter.innerHTML = "<div id='refreshFooter2' style='height: " + options.footerRefreshHeight + "px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>刷新完成</span>\n" +
                        "</div>";
                }
            }
                break;
            case 3: {
                if (options.footerHtml[3] != null && options.footerHtml[3].length > 0) {
                    _refreshFooter.innerHTML = options.footerHtml[3];
                } else {
                    _refreshFooter.innerHTML = "<div id='refreshFooter2' style='height: " + options.footerRefreshHeight + "px;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>加载完成</span>\n" +
                        "</div>";
                }
            }
                break;
        }
    }
}