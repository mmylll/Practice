var getDefaultOptions = function () {
    return {
        headerMaxHeigth: 150,//header最大高度
        headerRefreshHeight: 60,//header刷新组件高度
        headerHtml:["","","",""],//顶部刷新控件   刷新前，刷新中，刷新结束


        footerMaxHeight: 150,//底部最大下拉距离
        footerRefreshHeight: 60,//底部刷新时保持的高度
        footerHtml:["","","",""],//底部刷新控件   刷新前，刷新中，刷新结束

    };
}

/**
 *
 * @param parentId
 * @param scrollBodyId
 * @param onRefeshCall
 * @param onPullCall
 * @param options 配置参数  见 getDefaultOptions
 * @constructor
 */
function PTRefresh(parentId, scrollBodyId, onRefreshCall, onPullCall, options) {
    var parentArea = document.getElementById(parentId);//接收触摸的元素
    var scrollBody = document.getElementById(scrollBodyId);//滚动的主体区域
    var _refreshHeader = null;//刷新头部  背景标签
    var _headerStatus = 0;//header状态 0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败


    var _refreshFooter = null;//刷新底部 背景标签
    var _footerStatus = 0;//footer状态 0：默认状态，1在上拉中，2加载中，3加载完成，4加载失败
    var startPos = {x: 0, y: 0};//开始的位置
    var isScrolling = 0;//为1时，表示纵向滑动，0为横向滑动

    if (options == null){
        options = getDefaultOptions();
    }


    var self = this;

    setHeaderAndFooterInfo();

    //滑动开始
    var start = function (event) {
        if (_headerStatus != 0 || _footerStatus != 0) return;

        var isScrollTop = parentArea.scrollTop <= 0;//是否滚动到顶部

        var isScrollEnd = parentArea.scrollTop + parentArea.clientHeight + 2 >= scrollBody.clientHeight + _refreshFooter.clientHeight + _refreshHeader.clientHeight;


        var touch = event.targetTouches[0];     //touches数组对象获得屏幕上所有的touch，取第一个touch
        startPos = {x: touch.pageX, y: touch.pageY};    //取第一个touch的坐标值
        isScrolling = -1;   //这个参数判断是垂直滚动还是水平滚动

        if (isScrollTop && onRefreshCall != null || isScrollEnd && onPullCall != null) {
            addEventListener();
        }
    };
    //移动
    var move = function (event) {
        //当屏幕有多个touch或者页面被缩放过，就不执行move操作
        if (event.targetTouches.length > 1 || event.scale && event.scale !== 1) return;
        var touch = event.targetTouches[0];//第一个手指触摸点
        var movePos = {
            x: touch.pageX - startPos.x,
            y: touch.pageY - startPos.y
        };//手指在屏幕移动的位置

        if (isScrolling == -1) {
            isScrolling = (Math.abs(movePos.x) / 2 < Math.abs(movePos.y) ? 1 : 0);    //isScrolling为1时，表示纵向滑动，0为横向滑动
            // isScrolling = 1;
        }
        if (isScrolling == 1) {
            var isScrollTop = parentArea.scrollTop <= 0;//是否滚动到顶部
            if (movePos.y > 0) {
                if (onRefreshCall == null) {
                    deleteEventListener();
                    self.endRefreshOrPull();
                    return;
                }
                //在向下拉
                if (isScrollTop) {
                    var resultHeight = movePos.y / 3;
                    if (resultHeight > options.headerMaxHeight) {
                        resultHeight = options.headerMaxHeight;
                    }
                    _refreshHeader.style.height = resultHeight + "px";
                    _headerStatus = 1;
                }
            } else {
                //是否在底部呢
                var scrollContentHeight = scrollBody.clientHeight + _refreshFooter.clientHeight + _refreshHeader.clientHeight;
                var scrollCurrentEnd = parentArea.scrollTop + parentArea.clientHeight;
                var isScrollToEnd = scrollCurrentEnd + options.footerRefreshHeight >= scrollContentHeight;


                //在向上拉
                if (isScrollToEnd) {
                    if (onPullCall == null) {
                        deleteEventListener();
                        self.endRefreshOrPull();
                        return;
                    }

                    var resultHeight = -movePos.y;
                    if (resultHeight > options.footerMaxHeight) {
                        resultHeight = options.footerMaxHeight;
                    }

                    _refreshFooter.style.height = resultHeight + "px";
                    _footerStatus = 1;
                } else if (_refreshFooter.clientHeight > 0) {
                    var resultHeight = -movePos.y;
                    if (resultHeight > options.footerMaxHeight) {
                        resultHeight = options.footerMaxHeight;
                    }

                    _refreshFooter.style.height = resultHeight + "px";
                    $("#" + parentId).animate({
                        scrollTop: (parentArea.scrollHeight - parentArea.clientHeight) + "px",
                    }, 100);
                    // parentArea.scrollTo(0,parentArea.scrollHeight - parentArea.clientHeight);
                } else {
                    deleteEventListener();
                    self.endRefreshOrPull();
                }

            }
        }
    };
    //滑动释放
    var end = function (event) {
        if (isScrolling == 1) {    //当为竖直滚动时
            if (_headerStatus == 1) {
                //下拉中
                if (_refreshHeader.clientHeight >= options.headerRefreshHeight) {
                    self.setHeaderStatus(2);

                } else if (_refreshHeader.clientHeight > 0) {
                    self.setHeaderStatus(0);
                }
            }
            if (_footerStatus == 1) {
                //上拉中
                if (_refreshFooter.clientHeight > options.footerRefreshHeight) {
                    self.setFooterStatus(2);
                } else if (_refreshFooter.clientHeight > 0) {
                    self.setFooterStatus(0);
                }
            }
        }
        //解绑事件
        deleteEventListener();
    };


    var isTrue = true;
    //events对象
    scrollBody.addEventListener("touchstart", start, isTrue);

    //添加滚动监听事件
    function addEventListener() {
        document.addEventListener('touchmove', move, isTrue);
        document.addEventListener('touchend', end, isTrue);
    }

    //删除滚动监听事件
    function deleteEventListener() {
        document.removeEventListener('touchmove', move, isTrue);
        document.removeEventListener('touchend', end, isTrue);
    }

    this.setHeaderStatus = function (headerStatus) {
        _headerStatus = headerStatus;


        //0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
        switch (_headerStatus) {
            case 0: {//默认状态
                //将顶部刷新收回
                $("#" + _refreshHeader.id).animate({
                    height: "0px"
                }, 200, function () {
                    _headerStatus = 0;
                });
                _setHeaderStateElementHtml(0);
            }
                break;
            case 1: {//在下拉中

            }
                break;
            case 2: {//加载中
                _setHeaderStateElementHtml(1);
                $("#" + _refreshHeader.id).animate({
                    height: options.headerRefreshHeight + "px"
                }, 200);
                if (onRefreshCall != null) {
                    onRefreshCall();
                }
            }
                break;
            case 3: {//加载中
                _setHeaderStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshHeader.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _headerStatus = 0;
                        _setHeaderStateElementHtml(0);
                    });
                }, 300);
            }
                break;
            case 4: {//加载中
                _setHeaderStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshHeader.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _headerStatus = 0;
                        _setHeaderStateElementHtml(0);
                    });
                }, 300);

            }
                break;
        }
    }

    this.setFooterStatus = function (footStatus) {
        _footerStatus = footStatus;

        //0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
        switch (_footerStatus) {
            case 0: {//默认状态
                //将顶部刷新收回
                $("#" + _refreshFooter.id).animate({
                    height: "0px"
                }, 200, function () {
                    _footerStatus = 0;
                });
                _setFooterStateElementHtml(0);
            }
                break;
            case 1: {//在下拉中

            }
                break;
            case 2: {//加载中
                _setFooterStateElementHtml(1);
                $("#" + _refreshFooter.id).animate({
                    height: options.headerRefreshHeight + "px"
                }, 200);
                if (onPullCall != null) {
                    onPullCall();
                }
            }
                break;
            case 3: {//加载完成
                _setFooterStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshFooter.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _footerStatus = 0;
                        _setFooterStateElementHtml(0);
                    });
                }, 300);
            }
                break;
            case 4: {//加载中
                _setFooterStateElementHtml(2);
                setTimeout(function () {
                    $("#" + _refreshFooter.id).animate({
                        height: "0px"
                    }, 200, function () {
                        _footerStatus = 0;
                        _setFooterStateElementHtml(0);
                    });
                }, 300);

            }
                break;
        }
    }

    this.autoRefresh = function () {
        if (_headerStatus == 0 && _footerStatus == 0){
            self.setHeaderStatus(2);
        }
    };
    this.autoLoadMore = function () {
        if (_headerStatus == 0 && _footerStatus == 0){
            self.setFooterStatus(2);
        }
    }
    this.endRefreshOrPull = function () {
        self.setHeaderStatus(3);
        self.setFooterStatus(3);
    };

    /**
     * 设置头部跟底部的标签指示器
     */
    function setHeaderAndFooterInfo() {

        var headerHtml = "<div id='refreshHeader' style='position: relative;text-align: center;overflow: hidden;width: 100%;height: 0px;z-index: 1000;'> </div>";
        $("#" + parentId).prepend(headerHtml);


        var footerHtml = "<div id=\"refreshFooter\" style='position: relative;text-align: center;overflow: hidden;width: 100%;height: 0px;z-index: 1000;'></div>";
        $("#" + parentId).append(footerHtml);

        _refreshHeader = document.getElementById("refreshHeader");
        _refreshFooter = document.getElementById("refreshFooter");


        _setHeaderStateElementHtml(0);
        _setFooterStateElementHtml(0)
    }

    // 0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
    function _setHeaderStateElementHtml(status){
        let localUrl = window.location.href;
        var imgPath = localUrl.split("project")[0] + "base/imgs/";
        switch (status) {
            case 0:{
                if (options.headerHtml[0] != null && options.headerHtml[0].length > 0){
                    _refreshHeader.innerHTML = options.headerHtml[0];
                } else{
                    _refreshHeader.innerHTML = "<div id='refreshHeader0' style='display: inline-block;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_down.png'><span>放开我，我要刷新</span>\n" +
                        "</div>";
                }
            }
            break;
            case 1:{
                if (options.headerHtml[1] != null && options.headerHtml[1].length > 0){
                    _refreshHeader.innerHTML = options.headerHtml[1];
                } else{
                    _refreshHeader.innerHTML = "<div id='refreshHeader1' style='display: none;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter\">\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "loading.gif'><span>刷新中...</span>\n" +
                        "</div>";
                }
            }
            break;
            case 2:{
                if (options.headerHtml[2] != null && options.headerHtml[2].length > 0){
                    _refreshHeader.innerHTML = options.headerHtml[2];
                } else{
                    _refreshHeader.innerHTML = "<div id='refreshHeader2' style='display: none;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>刷新完成</span>\n" +
                        "</div>";
                }
            }
            break;
            case 3:{
                if (options.headerHtml[3] != null && options.headerHtml[3].length > 0){
                    _refreshHeader.innerHTML = options.headerHtml[3];
                } else{
                    _refreshHeader.innerHTML = "<div id='refreshHeader2' style='display: none;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>刷新完成</span>\n" +
                        "</div>";
                }
            }
            break;
        }
    }

    // 0：默认状态，1在下拉中，2加载中，3加载完成，4加载失败
    function _setFooterStateElementHtml(status){
        let localUrl = window.location.href;
        var imgPath = localUrl.split("project")[0] + "base/imgs/";
        switch (status) {
            case 0:{
                if (options.footerHtml[0] != null && options.footerHtml[0].length > 0){
                    _refreshFooter.innerHTML = options.footerHtml[0];
                } else{
                    _refreshFooter.innerHTML = "<div id='refreshFooter0' style='display: inline-block;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_down.png'><span>放开我，我要加载</span>\n" +
                        "</div>";
                }
            }
                break;
            case 1:{
                if (options.footerHtml[1] != null && options.footerHtml[1].length > 0){
                    _refreshFooter.innerHTML = options.footerHtml[1];
                } else{
                    _refreshFooter.innerHTML = "<div id='refreshFooter1' style='display: none;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter\">\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "loading.gif'><span>加载中...</span>\n" +
                        "</div>";
                }
            }
                break;
            case 2:{
                if (options.headerHtml[2] != null && options.headerHtml[2].length > 0){
                    _refreshFooter.innerHTML = options.headerHtml[2];
                } else{
                    _refreshFooter.innerHTML = "<div id='refreshFooter2' style='display: none;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>刷新完成</span>\n" +
                        "</div>";
                }
            }
                break;
            case 3:{
                if (options.footerHtml[3] != null && options.footerHtml[3].length > 0){
                    _refreshFooter.innerHTML = options.footerHtml[3];
                } else{
                    _refreshFooter.innerHTML = "<div id='refreshFooter2' style='display: none;font-size: 15px;color: #333333;padding: 20px 0px;' class='verticalCenter'>\n" +
                        "<img style='margin-right: 20px;max-height: 20px;' src='" + imgPath + "arrow_up.png'><span>加载完成</span>\n" +
                        "</div>";
                }
            }
                break;
        }
    }
}