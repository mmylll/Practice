
//banner工具
loadBaseFile("js/LLTool/swip/PTBanner.js");


var _bannerList = null;
var _bannerController = null;
//获取banner列表
function getBannerInfo (bannerId) {
    llApi.postNetData(ApiDatas.getBannerList, null, function (response) {
        if (response.code == 0) {
            _bannerList = response.data;
            var list = [];
            for (let i = 0; i < _bannerList.length; i++) {
                var item = _bannerList[i];
                list.push("<img src='" + item.url + "' style='width: 100%;height: 100%;' onclick='bannerItemClick(" + i + ")'>");
            }
            _bannerController = new PTbanner(bannerId, list, {
                isNeedPoint: true,
            });
        }
    }, function (err) {

    });
};

//banner点击事件
function bannerItemClick(index){
    var item = _bannerList[index];
    if (item.targetType == "info"){
        //跳转小说详情
        let params = {
            leader: "fishnovel",
            urlPath: NetRoutes.book_detail_view,
            params: jsonToStr({
                isShowNv: 0,
                isShowStatusBar: 1,
                id: item.jsonData,
            })
        };
        llApi.goToFunc(llLocalFuncCode.innerH5, params);
    }else if(item.targetType == "url"){
        llApi.goToFunc(llLocalFuncCode.webH5,item.jsonData);
    }
};