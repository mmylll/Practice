(function () {

    /**
     * 打开系统浏览器打开网页
     */
    llApi["sysOpenUrl"] = function (url) {
        llPerformSelectAction("sysOpenUrl", url);
    };
    /**
     * 获取app的缓存大小
     */
    llApi["appCacheSize"] = function (func) {
        llPerformSelectAction("appCacheSize", null, func);
    };
    /**
     * 清除app的缓存
     */
    llApi["clearCacheData"] = function () {
        llPerformSelectAction("clearCacheData", null, null);
    };
    /**
     * 获取app基本信息
     * @param func 回调方法,参数为app基本信息
     * {
     *     appVersion 版本号
     *     packName   包名 （appId）
     *     displayName   app名称
     * }
     */
    llApi["appSysInfo"] = function (func) {
        llPerformSelectAction("appSysInfo", null, func)
    };
    /**
     * 预加载本地连接
     * @param routeList 本地连接相对路径的数组
     */
    llApi["preLoadUrl"] = function (routeList) {
        var json = llJsonToStr(routeList);
        var base64 = llbase64.encode(json);
        llPerformSelectAction("preLoadUrl", base64, null)
    };
    /**
     * app打印日志
     */
    llApi["loge"] = function (str) {
        if (typeof(str) != "string") {
            str = llJsonToStr(str);
        }
        if (!llPerformSelectAction("loge", str, null)) {
            console.log(str);
        }
    };
    llApi["callTel"] = function (str) {
        llPerformSelectAction("callTel", str, null);
    };
    /**
     * 显示大图
     * @param imgUrl 图片链接
     */
    llApi["showBigImg"] = function (imgUrl) {
        llPerformSelectAction("showBigImg", imgUrl, null);
    };


    /**
     * 跳转app的内部功能
     * @param funcCode 跳转功能编号
     * @param paramsJson 跳转时传的参数
     */
    llApi["goToFunc"] = function (funcCode, paramsJson) {
        if (funcCode == null) return;
        let map = {
            funcCode: funcCode,
            paramsJson: llJsonToStr(paramsJson)
        }
        llPerformSelectAction("goToFunc", jsonToStr(map), null);
    };

    /**
     * 获取本地图片
     * @param isNeedCrop 是否需要裁方图，0：不需要 ， 1：需要
     * @param func 回调方法,参数为图片base64编码格式
     */
    llApi["getOneImg"] = function (isNeedCrop, func) {
        llApi.getOneLocalImg(isNeedCrop, 1, 1, 1000, 1800, func)
    };
    /**
     * 获取本地图片
     * @param isNeedCrop
     * @param scropX
     * @param scropY
     * @param maxWidth
     * @param maxHeight
     * @param func 回调方法,参数为图片base64编码格式
     */
    llApi["getOneLocalImg"] = function (isNeedCrop, scropX, scropY, maxWidth, maxHeight, func) {
        llApi.getLocalImg(isNeedCrop, 1, scropX, scropY, maxWidth, maxHeight, function (list) {
            if (func != null) {
                if (list != null && list.length > 0) {
                    func(list[0]);
                }
            }

        });
    };
    /**
     * 获取本地图片图片base64
     * @param isNeedCrop 是否需要裁剪
     * @param maxCount 最大数量
     * @param scropX 裁剪比例 x
     * @param scropY 裁减比例y
     * @param maxWidth 最大宽度
     * @param maxHeight 最大高度
     * @param func 参数为图片base64之后的数组
     */
    llApi["getLocalImg"] = function (isNeedCrop, maxCount, scropX, scropY, maxWidth, maxHeight, func) {
        let params = {
            isNeedCrop: isNeedCrop,
            scropX: scropX,
            scropY: scropY,
            maxWidth: maxWidth,
            maxHeight: maxHeight
        };
        let str = llJsonToStr(params);
        llApi.loge(str);
        llPerformSelectAction("getLocalImg", str, func);
    };
    /**
     * 获取本地图片上传服务器之后的图片链接
     * @param isNeedCrop 是否需要裁剪
     * @param maxCount 最大数量
     * @param scropX 裁剪比例 x
     * @param scropY 裁减比例y
     * @param maxWidth 最大宽度
     * @param maxHeight 最大高度
     * @param func 参数为图片链接
     */
    llApi["getLocalImgUrl"] = function (isNeedCrop, scropX, scropY, maxWidth, maxHeight, func) {
        let params = {
            isNeedCrop: isNeedCrop,
            maxCount: 1,
            scropX: scropX,
            scropY: scropY,
            maxWidth: maxWidth,
            maxHeight: maxHeight
        };
        let str = llJsonToStr(params);
        llApi.loge(str);
        llPerformSelectAction("getLocalImgUrl", str, func);
    };
    /**
     * 加载网络图片
     * @param imgUrl
     * @param func回调函数 参数：imgData本地下载后的base64图片
     */
    llApi["loadNetImgData"] = function (imgUrl, func) {
        llPerformSelectAction("loadNetImgData", imgUrl, func);
    };

    /**
     * 复制文本到粘贴板
     * @param dataStr 粘贴的数据
     * @param func 是否粘贴成功,参数 1标示成功，0失败
     */
    llApi["saveTextToClipboard"] = function (dataStr, func) {
        if (dataStr == null || typeof(dataStr) != "string") return;
        llPerformSelectAction("saveTextToClipboard", dataStr, func);
    };


    /**
     * 默认不显示指示动画,get方法
     * @param url 不是完整链接，跟原生baseUrl拼接好之后才是完整链接
     * @param paramsMap 参数模型map
     * @param succeedMethod
     * @param faildMethod
     */
    llApi["getNetData"] = function (url, paramsMap, succeedMethod, faildMethod) {
        let map = {};
        map["url"] = url;
        if (paramsMap != null) {
            let params = llbase64.encode(llJsonToStr(paramsMap));
            map["params"] = params;
        }
        let params = llJsonToStr(map);
        llPerformSelectAction("getBase64Data", params, function (dataModel) {
            try {
                let dataStr = llbase64.decode(llJsonToStr(dataModel));
                dataModel = llJsonToModel(dataStr);
                if (dataModel.code == 0) {
                    //成功
                    if (succeedMethod != null) {
                        succeedMethod(llJsonToModel(dataModel.data));
                    }
                } else {
                    //失败
                    if (faildMethod != null) {
                        faildMethod(dataModel.msg);
                    }
                }
            } catch (e) {
                faildMethod(e.description);
            }
        });
    };
    /**
     * 默认不显示指示动画，post方法
     * @param url 不是完整链接，跟原生baseUrl拼接好之后才是完整链接
     * @param paramsMap 参数模型map
     * @param succeedMethod
     * @param faildMethod
     */
    llApi["postNetData"] = function (url, paramsMap, succeedMethod, faildMethod) {
        let map = {};
        map["url"] = url;
        if (paramsMap != null) {
            let params = Base64.encode(llJsonToStr(paramsMap));//llbase64.encode(llJsonToStr(paramsMap));
            map["params"] = params;
        }
        let params = llJsonToStr(map);
        llPerformSelectAction("loadBase64Data", params, function (dataModel) {
            var dataStr = Base64.decode(llJsonToStr(dataModel));//llbase64.decode(llJsonToStr(dataModel));
            dataModel = llJsonToModel(dataStr);
            if (dataModel.code == 0) {
                //成功
                if (succeedMethod != null) {
                    succeedMethod(llJsonToModel(dataModel.data));
                }
            } else {
                //失败
                if (faildMethod != null) {
                    faildMethod(dataModel.msg);
                }
            }

            // try {
            //
            // } catch (e) {
            //     faildMethod(e.description);
            // }
        });
    };

    /**
     * 是否显示蒙版
     * @param isShow 0不显示，1显示
     */
    llApi["showMask"] = function (isShow) {
        llPerformSelectAction("showMask", isShow + "", null);
    };


})();
