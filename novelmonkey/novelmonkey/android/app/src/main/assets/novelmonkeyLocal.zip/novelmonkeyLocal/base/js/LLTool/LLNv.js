/**
 * 导航信息
 * @param hideback 隐藏返回
 * @param title 标题
 */
Vue.component('ll-nv', {
    props: {
        hideback:Boolean,//是否隐藏返回按钮
        returnImg:String,//返回按钮的图片路径
        isbackbtnblack:Boolean,//返回按钮样式 false白色，true黑色
        title:String,//标题
    },
    template: "<div class='nv_bg nv_color' style='position: fixed;z-index: 9999;'>" +
        "<span>{{title}}</span>" +
        "<img :src='returnImgUrl' class='nv_left_btn' onclick='llApi.pop(0,null);' v-if='hideback==false'>" +
        "<div class='nv_right_btn_bg'><slot></slot></div>" +
        "</div>",
    data: function(){

    },
    computed: {
        returnImgUrl: function () {
            if (this.returnImg == null){
                if (this.isbackbtnblack != null & this.isbackbtnblack){
                    let url = window.location.href;
                    let leftPath = url.split("project")[0];
                    return leftPath + "base/imgs/go_back_black_arrow.png";
                } else{
                    let url = window.location.href;
                    let leftPath = url.split("project")[0];
                    return leftPath + "base/imgs/go_back_white_arrow.png";
                }

            }
            return this.returnImg;
        }
    },
    methods:{

    }
})