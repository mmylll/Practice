(function () {


    /**
     * 发起微信支付
     * @param payData 预支付的数据
     * @param func 支付结果,errCode 0:成功,-1:失败,-2:取消
     */
    llApi["wxPay"] = function (payData, func) {
        llPerformSelectAction("wxPay", jsonToStr(payData), func);
    };
    /**
     * 微信登录
     * @param func 返回登录信息
     * nick_name  昵称
     * header_url 头像
     * openid 授权id
     * unionid 唯一标示
     * gender 性别
     */
    llApi["wxLogin"] = function (func) {
        llPerformSelectAction("wxLogin", null, func);
    };
    /**
     * 友盟统计登录信息
     * @param userId 用户id （登出时传空）
     * @param thirdName (第三方登录时的名称)
     */
    llApi["umMobClickLogin"] = function (userId, thirdName) {
        var params = {};
        if (thirdName != null) {
            params.userId = userId;
        }
        if (thirdName != null) {
            params.thirdName = thirdName;
        }
        llPerformSelectAction("umMobClickLogin", jsonToStr(params), null);
    };
    /**
     * 统计事件
     * @param eventId 事件id（字符串） 对应[umEventKeys]
     * @param eventMap (事件里面的信息)
     */
    llApi["umMobClickEvent"] = function (eventId, eventMap) {
        if (eventId == null || eventId.length == 0 || eventMap == null) return;
        var params = {
            eventId: eventId,
            eventMap: eventMap
        }
        llPerformSelectAction("umMobClickEvent", llJsonToStr(params), null);
    };
    /**
     * 统计事件
     * @param pageName
     * @param isShow
     */
    llApi["umMobClickPageShow"] = function (pageName, isShow) {
        if (pageName == null || pageName.length == 0) return;
        let params = {
            pageName: pageName,
            isShow: isShow
        }
        llPerformSelectAction("umMobClickPageShow", llJsonToStr(params), null);
    };
    /**
     * 分享相关api
     */
    /**
     * 通知app分享，让用户直接拉起分享功能
     * @param shareTitle 分享好友的标题
     * @param shareContent 分享好友的富文本
     * @param shareLinkUrl 分享链接
     * @param shareCircleText 分享朋友圈的文本
     * @param shareImgUrl 图片链接或者图片base64格式化字符串
     * @param shareType 分享类型 0：链接，1：图片
     * @param platForm 分享的平台 0：微信好友，1：微信朋友圈 2保存图片  3QQ好友 4qq控件
     * @param func 回调方法
     */
    llApi["goShare"] = function (shareTitle, shareContent, shareCircleText, shareLinkUrl, shareImgUrl, shareType, platForm,func) {
        var shareInfor = {};
        shareInfor["shareTitle"] = shareTitle;
        shareInfor["shareContent"] = shareContent;
        shareInfor["shareCircleText"] = shareCircleText;
        shareInfor["shareLinkUrl"] = shareLinkUrl;
        shareInfor["shareImgUrl"] = shareImgUrl;
        shareInfor["shareType"] = shareType;
        shareInfor["platForm"] = platForm;
        let str = llJsonToStr(shareInfor);
        llPerformSelectAction("goShare", str, func);
    };
    /**
     * 通知app显示分享面板
     * @param shareTitle 分享好友的标题
     * @param shareContent 分享好友的富文本
     * @param shareCircleText 分享朋友圈的内容
     * @param shareLinkUrl 分享链接
     * @param shareImgUrl 图片链接或者图片base64格式化字符串
     * @param shareType 分享类型 0：链接，1：图片
     */
    llApi["showShareBoard"] = function (shareTitle, shareContent, shareCircleText, shareLinkUrl, shareImgUrl, shareType) {
        var shareInfor = {};
        shareInfor["shareTitle"] = shareTitle;
        shareInfor["shareContent"] = shareContent;
        shareInfor["shareCircleText"] = shareCircleText;
        shareInfor["shareLinkUrl"] = shareLinkUrl;
        shareInfor["shareImgUrl"] = shareImgUrl;
        shareInfor["shareType"] = shareType;
        let str = llJsonToStr(shareInfor);
        llPerformSelectAction("showShareBoard", str, null);
    };
})();

let umEventKeys = {
    searchKey: "searchKey",//搜索页面搜索了关键字
}