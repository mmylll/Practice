/**
 * 导入swipe库
 */
(function () {
    let url = window.location.href;
    let leftPath = url.split("project")[0];
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/swip/swipe.js" + "'></script>");
})();

/**
 * https://github.com/thebird/Swipe
 *
 * banner  请使用new PTbanner();创建对象
 * @param rootId 根视图的id
 * @param itemList item的html 字符串数组
 * @param options 配置参数
 * {
 *     isNeedPoint 是否需要指示点
 *     continuous  是否循环播放 默认是
 *     autoRun  是否自动循环，默认自动
 *     autoRunTimer 自动循环时的时间间隔，默认5s
 * }
 * @constructor
 */
function PTbanner(rootId, itemList, options) {
    if (itemList.length == 0)return;
    var currentIndex = 0;
    if (options == null)options= {};

    var list = [];
    list.push(itemList[itemList.length - 1]);
    itemList.forEach(function (item) {
        list.push(item);
    });
    list.push(itemList[0]);


    let rootEle = document.getElementById(rootId);
    rootEle.style.position = "relative";

    let html = '<div id="pt_bannerBg" style="overflow: hidden;visibility:hidden;position:relative;width:100%;height: 100%;">';
    html += '<div style="overflow: hidden;position: relative;height: 100%;">';
    //添加元素
    if (list != null) {
        for (let i = 0; i < list.length; i++) {
            html += '<div style="float: left;width: 100%;height: 100%; position: relative;">';
            html += list[i];
            html += '</div>';
        }
    }
    html += "</div>";
    html += "</div>";

    if (options.isNeedPoint != null && options.isNeedPoint == true){
        //添加指引点点
        html += '<div></div><div style="position: absolute;left: 0px;right: 0px;bottom: 10px;text-align: center;z-index: 1001;-webkit-transform: translateZ(0);">';
        //添加元素
        if (itemList != null) {
            for (let i = 0; i < itemList.length; i++) {
                html += '<div id="banner_point_' + i + '" style="display: inline-block;width: 6px;height: 6px;border-radius: 3px;background-color: white;margin-left: 5px;"></div>';
            }
        }
        html += '</div>';
    }



    rootEle.innerHTML = html;

    //滚动视图
    setTimeout(function () {
        let swipEle = document.getElementById("pt_bannerBg");
        window.mySwipe = Swipe(swipEle, {
            startSlide:1,
            auto: options.autoRunTimer == null ? 5000 : options.autoRunTimer,
            continuous: options.autoRun == null ? true : options.autoRun,
            // disableScroll: true,
            // stopPropagation: true,
            callback: function (index, element) {

                if (index == 0){
                    currentIndex = itemList.length - 1;
                }else if (index == list.length - 1){
                    currentIndex = 0;
                }else{
                    currentIndex = index - 1;
                }
                refreshPoints();

            },
            // transitionEnd: function(index, element) {}
        });
        // refreshPoints();
    },200);

    function refreshPoints() {
        if (options.isNeedPoint != null && options.isNeedPoint == true) {
            for (let i = 0; i < itemList.length; i++) {
                let pointEle = document.getElementById("banner_point_" + i);
                if (i == currentIndex) {
                    pointEle.style.backgroundColor = "rgba(255,255,255,1)";
                } else {
                    pointEle.style.backgroundColor = "rgba(255,255,255,0.5)";
                }
            }
        }
    }
}