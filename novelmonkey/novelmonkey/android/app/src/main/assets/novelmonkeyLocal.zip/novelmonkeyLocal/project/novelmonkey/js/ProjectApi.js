(function () {

    /**
     * 获取用户信息
     * @param func 返回用户信息，参数为用户信息
     */
    llApi["getUserData"] = function (func) {
        llPerformSelectAction("getUserData", null, func);
    };


    //用户登录成功回调原生
    llApi["userLoginOk"] = function () {
        llPerformSelectAction("userLoginOk", null, null);
    };

    /**
     * 加载章节信息
     * @param bookId
     * @param chapterId
     * @param isShowDialog
     * @param func {code:0,msg:'成功',data:"章节内容"}
     */
    llApi["getChapterText"] = function (bookId,chapterId,downloadUrl,isShowDialog,isOnlyPrepare,func) {
        var params = {
            bookId: bookId,
            chapterId: chapterId,
            isShowDialog:isShowDialog ? 1 : 0,
            isOnlyPrepare : isOnlyPrepare ? 1 : 0,
        };
        if (downloadUrl != null){
            params["downloadUrl"] = downloadUrl;
        }


        llPerformSelectAction("getChapterText",jsonToStr(params),func);
    }

    llApi["getUserBodyInfo"] = function(func){
        llApi.getCacheData("user_body_info",function (data) {
            if (data == null){
                llApi.refreshUserInfoData(func);
            } else{
                if (func != null){
                    func(data);
                }
            }
        })
    };
    /**
     * 加载章节信息
     * @param bookId
     * @param chapterId
     * @param isShowDialog
     * @param func {code:0,msg:'成功',data:"章节内容"}
     */
    llApi["refreshUserInfoData"] = function (func) {
        llApi.postNetData(ApiDatas.getUserDetail, {}, function (resp) {
            if (resp.code == "000") {

                var userData = resp.content;

                //缓存到本地
                llApi.cacheData("user_body_info",userData);


                if (func != null){
                    func(userData);
                }
            }
        })
    }

    llApi["getUserLibraryList"] = function (func) {
        llApi.getCacheData("user_library_list",function (data) {
                if (data !=  null){
                    if (func){
                        func(data.list);
                    }
                } else{
                    llApi.postNetData(ApiDatas.getUserLibraryList, {}, function (resp) {
                        if (resp.code == "000") {
                            bodyData.userLibraryList = resp.content.list;
                        } else {

                        }
                    }, function (err) {

                    });
                }
        })
    }

    /**
     * 数据统计
     * @param name
     * @param paramsObj
     */
    llApi["monkey_analysis"] = function (name,paramsObj) {
        var params = {key:name};
        if (paramsObj != null){
            params.value = paramsObj;
        }
        llPerformSelectAction("monkey_analysis",jsonToStr(params),null);
    }
})();



