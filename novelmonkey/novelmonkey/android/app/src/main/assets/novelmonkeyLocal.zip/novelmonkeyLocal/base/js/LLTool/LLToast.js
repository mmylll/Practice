//加载状态为complete时移除loading效果
function toast(content) {
	var html = "<div id='pttoast' style='position: fixed; top: 50%; width: 100%; text-align: center; background-color: transparent;z-index: 99999;'><div style='padding: 10px 13px 8px 13px; border-radius: 5px; background: rgba(0, 0, 0, 0.5);display: inline-block;color: white; font-size: 13px;line-height: 15px;'>"
			+ content +"</div></div>";
	$("body").append(html);
	setTimeout(function() {
		$("#pttoast").remove();
	}, 1500);
}

//加载动画
function showPTMask() {
	var mask = document.getElementById("PTMASKID");
	if (mask != null)return;
	var url = window.location.href.split("/html/")[0] + "/imgs/loading.gif";
	var img = url.length == 0 ? "" : "<img style='z-index: 20001;position: fixed;margin: auto;left: 0px;right: 0px;top: 0px;bottom: 0px;width: 30px;height: 30px;' src='" + url + "'>";
    var html = "<div id='PTMASKID' style='z-index: 20000;position: fixed;margin: auto;left: 0px;right: 0px;top: 0px;bottom: 0px;background-color: rgba(0,0,0,0.2);text-align: center;display: block;'>" + img + "</div>";
    $("body").append(html);
}
function dismissPTMask() {
    $("#PTMASKID").remove();
}
