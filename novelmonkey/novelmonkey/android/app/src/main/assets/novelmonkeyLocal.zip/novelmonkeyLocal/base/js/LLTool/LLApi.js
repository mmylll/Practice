/**
 * 统一处理android、ios js  接口
 * @param actionName 方法名称（需与原生约定好）
 * @param jsonStr js传给原生的json数据
 * @param func原始回调方法(不需要回调的请传null)
 * @return boolean 是否是Android或者ios设备
 */
function llPerformSelectAction(actionName, jsonStr, func) {
    // actionCode 回调使用的，不需要回调的请传-1（页面新增的接口误用10000以下的数字）
    let actionCode = parseInt(Math.random() * 1000) + "";
    if (func != null) {
        llResult.appCalljsFuncMap[actionCode + ""] = func;
    }

    if (jsonStr == null) {
        jsonStr = "";
    }
    let u = navigator.userAgent;
    let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
    let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

    try {
        if (isiOS) {
            let params = {};
            params["actionName"] = actionName;
            params["actionCode"] = actionCode;
            params["json"] = jsonStr;
            window.webkit.messageHandlers.jsToOcWithPrams.postMessage(params);
            return true;
        } else if (isAndroid && WTK != null) {
            WTK.jsCallAndroid(actionName, actionCode, jsonStr);
            return true;
        }
    } catch (e) {

    }

}

/**
 * 原生调用js接口,开发人员没有必要请勿改动
 */
let llResult = {
    /**
     * js获取数据app回调对应的id跟方法
     * @type {{}}
     */
    appCalljsFuncMap: {},
    /**
     * @param data 数据模型
     */
    toJsResult: function (actionCode, jsonStr) {
        var returnMethod = llResult.appCalljsFuncMap[actionCode + ""];
        if (returnMethod != null) {
            delete llResult.appCalljsFuncMap[actionCode + ""];
            var data = jsonStr;
            if (typeof(jsonStr) == "string" && (jsonStr.startsWith("{") || jsonStr.startsWith("["))) {
                data = llJsonToModel(jsonStr);
            }
            returnMethod(data);
        }
    }
}

/**
 * 已经做好的api接口
 */
var llApi = {
};

/**
 * 当前页面缓存原生主动调用js的方法
 */
var llFuncCacheData = {};
/**
 * 当前页面缓存的key
 */
var llFuncCacheKey = {
    viewWillApearKey: "viewWillApearKey",//页面将要显示
    viewWillDisAppearKey: "viewWillDisAppearKey",//页面将要离开
    viewReturnDataKey: "viewReturnDataKey",//下一页面给返回数据
};
/**
 * 原生直接回调js的方法
 */
var llFunc = {

};
/**
 * 本地功能列表名称
 * @type {{}}
 */
var llLocalFuncCode = {
    /**
     * 本地存储的内部h5，不受服务器控制的
     * {
                    leader: "yayi",
                    urlPath: AppRoutes.articleDetail,
                    params: jsonToStr({
                        isShowNv: 1,
                        isShowStatusBar: 1,
                        articleId: item.id,
                    })
                }
     */
    localInnerH5:"localInnerH5",
    /**
     * 服务器控制的内部h5
     * 参数格式
     * {
                    leader: "yayi",
                    urlPath: "",
                    params: jsonToStr({
                        isShowNv: 1,
                        isShowStatusBar: 1,
                        articleId: item.id,
                    })
                }
     */
    innerH5:"innerH5",//
    webH5:"webH5", //外部链接
}



/**
 * 模型转json
 * @param model
 * @returns {string}
 */
function llJsonToStr(model) {
    if (model == null) return null;
    if (typeof (model) == 'string') return model;
    return JSON.stringify(model);
}

/**
 * 将json字符串转成对象
 * @param str
 * @returns 模型
 */
function llJsonToModel(str) {
    var model = str;
    if (typeof (str) == 'string') {
        str = str.replaceAll("\n", "\\n");
        str = str.replaceAll("\r", "\\r");
        model = JSON.parse(str);
    }
    return model;
}

/**
 * 接入其他的api
 */
(function () {
    let url = window.location.href;
    let arr = url.split("project");
    let leftPath = "";
    if (arr.length == 2) {
        //说明这是项目的路径
        leftPath = arr[0];

    }else{
        arr = url.split("base");
        //说明这是基础类的路径
        leftPath = arr[0];
    }
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLApis/LLBaseApi.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLApis/LLCacheApi.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLApis/LLUmengApi.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "base/js/LLTool/LLApis/LLViewControllerApi.js" + "'></script>");
    // document.write("<link rel='stylesheet' href='" + leftPath + "css/base/ll_project_base.css?v=1'>");
})();