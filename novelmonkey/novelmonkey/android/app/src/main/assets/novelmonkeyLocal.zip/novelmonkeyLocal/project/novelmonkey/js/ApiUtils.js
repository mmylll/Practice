let _pjBaseUrl = "https://www.novelmonkey.app/anybook-web/";
let ApiDatas = {

    /**
     *获取用户信息
     */
    getUserDetail:_pjBaseUrl + "confined/account/getAccountInfo",
    /**
     * 获取书籍详情
     */
    getBookDetail:_pjBaseUrl + "confined/book/getBookInfo",

    /**
     * 书架列表
     */
    getUserLibraryList:_pjBaseUrl + "confined/book/getBooksFromBookShelf",

    /**
     * 添加到书籍
     */
    addToLibrary:_pjBaseUrl + "confined/book/addBookToBookshelf",

    /**
     * 保存阅读进度
     */
    saveReadProgress: _pjBaseUrl + "confined/book/addReadingProgress",

    /**
     * 统计阅读时长
     */
    saveReadingDuration: _pjBaseUrl + "confined/book/saveReadingDuration",
}