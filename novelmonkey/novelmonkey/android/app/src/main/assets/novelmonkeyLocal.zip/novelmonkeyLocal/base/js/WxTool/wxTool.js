document.write("<script language=javascript src='http://res2.wx.qq.com/open/js/jweixin-1.4.0.js'></script>");

var wxTool = new function () {
    //不可外部使用,判断微信是否准备好了
    var wxReady = false;
    //不可外部使用，为准备好的时候，朋友圈的分享内容设置
    var circleData = null;
    //不可外部使用，为准备好的时候，好友聊天的分享内容设置
    var appMsgData = null;

    /**
     * 微信公众号初始化
     * @param appId
     * @param timestamp
     * @param noncestr
     * @param signature
     * @param jsApiList 接口数组[
     *      'chooseWXPay', //js支付
     *     'onMenuShareTimeline',//分享到朋友圈
     *      'onMenuShareAppMessage'//分享到聊天
     * ]
     */
    initWxSignData = function (signData,apiList) {
        if (apiList == null)apiList = {};
        initWxData(
            signData.appId,
            signData.timestamp,
            signData.noncestr,
            signData.signature,
            apiList
        );
    };
    this.initWxSignData = initWxSignData

    function initWxData(appId, timestamp, noncestr, signature, jsApiList) {
        wx.config({
            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: appId, // 必填，公众号的唯一标识
            timestamp: timestamp, // 必填，生成签名的时间戳
            nonceStr: noncestr, // 必填，生成签名的随机串
            signature: signature,// 必填，签名，见附录1
            jsApiList: jsApiList
            // [ 'onMenuShareTimeline',
            // 'onMenuShareAppMessage' ]
        });
        wx.ready(function () {
            wxReady = true;
            if (circleData != null) {
                setWxCicleData(
                    circleData.title,
                    circleData.link,
                    circleData.imgUrl,
                    circleData.success
                );
            }
            if (appMsgData != null) {
                wxTool.setWxMsgData(
                    appMsgData.title,
                    appMsgData.desc,
                    appMsgData.link,
                    appMsgData.imgUrl,
                    appMsgData.type,
                    appMsgData.dataUrl,
                    appMsgData.success);
            }
        });
        wx.error(function (res) {
        })
    };


    /**
     * 设置分享朋友圈的内容
     * @param title
     * @param link
     * @param imgUrl
     * @param success
     * @param cancel
     */
    setWxCicleData = function (title, link, imgUrl, success) {
        if (wxReady) {
            wx.onMenuShareTimeline({
                title: title, // 分享标题
                link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                imgUrl: imgUrl, // 分享图标
                success: success
            });
        } else {
            circleData = {
                title: title,
                link: link,
                imgUrl: imgUrl,
                success: success
            };
        }
    };
    this.setWxCicleData = setWxCicleData;


    /**
     * 设置分享给好友的内容
     * @param title
     * @param desc
     * @param link
     * @param imgUrl
     * @param type // 分享类型,music、video或link，不填默认为link
     * @param dataUrl // 如果type是music或video，则要提供数据链接，默认为空
     * @param success
     * @param cancel
     */
    setWxMsgData = function (title, desc, link, imgUrl, type, dataUrl, success) {
        if (wxReady) {
            wx.onMenuShareAppMessage({
                title: title, // 分享标题
                desc: desc,
                link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                imgUrl: imgUrl, // 分享图标
                type: type,
                dataUrl: dataUrl,
                success: success
            });
        } else {
            appMsgData = {
                title: title, // 分享标题
                desc: desc,
                link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                imgUrl: imgUrl, // 分享图标
                type: type,
                dataUrl: dataUrl,
                success: success
            };
        }
    };
    this.setWxMsgData = setWxMsgData;

    /**
     * 微信支付
     * @param jsonMap 服务器生成的预支付信息
     * @param resultFunc 回调方法
     */
    this.wxPay = function (jsonMap,resultFunc) {
        wx.chooseWXPay({
            timestamp : jsonMap.timeStamp,
            nonceStr : jsonMap.nonceStr,
            package : jsonMap.package,
            signType : 'MD5',
            paySign : jsonMap.paySign,
            success : function(res) {
                if (resultFunc != null){
                    resultFunc(res);
                }

                // if(res.err_msg == "get_brand_wcpay_request:ok" ) {
                //     console.log('支付成功');
                //     //支付成功后跳转的页面
                // }else if(res.err_msg == "get_brand_wcpay_request:cancel"){
                //     console.log('支付取消');
                // }else if(res.err_msg == "get_brand_wcpay_request:fail"){
                //     console.log('支付失败');
                //     WeixinJSBridge.call('closeWindow');
                // } //使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回ok,但并不保证它绝对可靠。

            }
        });
    };
}();