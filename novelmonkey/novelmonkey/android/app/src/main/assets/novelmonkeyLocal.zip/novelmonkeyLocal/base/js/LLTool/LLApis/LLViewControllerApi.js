(function () {


    /**
     * 设置页面标题
     * @param str
     */
    llApi["setTitle"] = function (str) {
        llPerformSelectAction("setTitle", str, null);
    };
    /**
     * 获取页面链接的leader
     */
    llApi["getInnerH5Leader"] = function () {
        let selfUrl = window.location.href;
        let leftPath = selfUrl.split("/project")[0];
        let list = leftPath.split("/");
        let appLeader = list[list.length - 1];
        return appLeader + "/";
    };

    /**
     * 是否显示返回按钮
     * @param showBackBtn 0不显示，1显示
     */
    llApi["showBackBtn"] = function(showBackBtn){
        llPerformSelectAction("showBackBtn",showBackBtn+"",null);
    };
    /**
     * 跳转新页面
     * @param url 省略leader部分的剩下的链接
     * @param params 参数（map类型）
     * @param isFinishSelf 是否关闭自己，0不关闭，1关闭(只在一个导航下跳转页面时生效)
     * @param urlType 链接类型，0服务器控制的本地连接，1本地控制的本地连接，2其他链接
     * @param isNewNv 是否是新的导航，1是，0不是
     * @param isShowNv 是否显示导航栏 1是 0不是
     * @param isShowStatausBar 是否显示状态栏 1是 0不是
     */
    llApi["gotoNextVc"] = function (url, params, isFinishSelf, urlType, isNewNv, isShowNv, isShowStatusBar) {
        if (urlType == 0 || urlType == 1) {
            url = llApi.getInnerH5Leader() + url;
        }

        if (params == null) {
            params = {};
        }
        params.isShowNv = isShowNv;
        params.isShowStatusBar = isShowStatusBar;
        let paramsJson = llbase64.encode(jsonToStr(params))

        var data = {
            url: url,
            paramsJson: paramsJson,
            isFinishSelf: isFinishSelf,
            urlType: urlType,
            isNewNv: isNewNv
        }
        llPerformSelectAction("goToNextVc", jsonToStr(data), null);
    };
    /**
     * 获取当前网页链接里面的数据
     * @param func 回调数据，参数为map
     */
    llApi["getUrlParams"] = function (func) {
        llPerformSelectAction("getUrlParams", null, function (params) {
            if (params != null) {
                let json = llbase64.decode(params);
                let data = jsonToModel(json);
                llApi.loge(data);
                if (func != null) {
                    func(data);
                }
            }
        });
    };
    /**
     * app页面回退
     * @param isNewNv 是否关闭导航，1是，0不是
     * @param jsonData 回传的数据
     */
    llApi["pop"] = function (isFinishNv, jsonData) {
        var data = {
            isFinishNv: isFinishNv,
        };
        if (jsonData != null) {
            data.jsonData = jsonToStr(jsonData);
        }
        llPerformSelectAction("pop", jsonToStr(data), null);
    };
    /**
     * 页面将要显示
     * @param func，无参数
     */
    llApi["viewWillAppear"] = function (func) {
        if (func != null) {
            llFuncCacheData[llFuncCacheKey.viewWillApearKey] = func;
        }
    };
    /**
     * 页面将要离开
     * @param func，无参数
     */
    llApi["viewWillDisAppear"] = function (func) {
        if (func != null) {
            llFuncCacheData[llFuncCacheKey.viewWillDisAppearKey] = func;
        }
    };
    /**
     * 页面返回时监听返回的数据
     * @param func，参数data 为对象
     */
    llApi["viewReturnData"] = function (func) {
        if (func != null) {
            llFuncCacheData[llFuncCacheKey.viewReturnDataKey] = func;
        }
    };
    /**
     * 获取状态栏高度
     * @param func，参数data 为状态栏高度
     */
    llApi["getStatusBarHeight"] = function (func) {
        llPerformSelectAction("statusBarHeight", null, func);
    };
    /**
     * 设置是否显示状态栏
     * @param isShowStatus 字符串 0不显示，1显示
     */
    llApi["showStatusBar"] = function (isShowStatus) {
        llPerformSelectAction("showStatusBar", isShowStatus, null);
    };
    /**
     * 设置是否显示导航栏
     * @param isShowStatus 字符串 0不显示，1显示
     */
    llApi["showNv"] = function (isShowNv) {
        if (isShowNv == false) {
            setTimeout(function () {
                llPerformSelectAction("showNv", isShowNv, null);
            }, 10);
        } else {
            llPerformSelectAction("showNv", isShowNv, null);
        }

    };
    /**
     * 获取屏幕亮度
     * @param func 参数屏幕亮度，0 - 1
     */
    llApi["getScrrenLight"] = function(func){
        llPerformSelectAction("getScrrenLight", null, func);
    }

    /**
     * 设置屏幕亮度
     * @param lightValue 参数屏幕亮度，0 - 1
     */
    llApi["setScrrenLight"] = function(lightValue){
        llPerformSelectAction("setScrrenLight", lightValue + "", null);
    }

    /**
     * 设置屏幕是否常亮
     * @param isStillLight 是否常亮，1常亮，0不常亮
     */
    llApi["setScrrenStillLight"] = function(isStillLight){
        llPerformSelectAction("setScrrenStillLight", isStillLight + "", null);
    }






    /**
     * 下一个页面返回给前端的数据
     * @param jsonStr json数据
     */
    llFunc["viewReturnData"] = function (jsonStr) {
        var data = jsonStr;
        if (typeof(jsonStr) == "string" && (jsonStr.startsWith("{") || jsonStr.startsWith("["))) {
            data = llJsonToModel(jsonStr);
        }
        let func = llFuncCacheData[llFuncCacheKey.viewReturnDataKey];
        if (func != null) {
            func(data);
        }
    };
    /**
     * 页面将要显示
     */
    llFunc["viewWillAppear"] = function () {
        let func = llFuncCacheData[llFuncCacheKey.viewWillApearKey];
        if (func != null) {
            func();
        }
    };
    /**
     * 页面将要离开
     */
    llFunc["viewWillDisAppear"] = function () {
        let func = llFuncCacheData[llFuncCacheKey.viewWillDisAppearKey];
        if (func != null) {
            func();
        }
    }
})();

