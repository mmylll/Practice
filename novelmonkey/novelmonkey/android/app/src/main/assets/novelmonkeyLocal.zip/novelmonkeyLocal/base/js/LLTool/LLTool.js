/**
 * 判断是否是手机号
 */
function isPhoneNum(num) {
    var myreg = /^[1][3,4,5,7,8,9][0-9]{9}$/;
    if (myreg.test(num)) {
        return true;
    } else {
        return false;
    }
}
String.prototype.replaceAll  = function(s1,s2){
    return this.replace(new RegExp(s1,"gm"),s2);
}
Array.prototype.remove = function (dx) {

    if (isNaN(dx) || dx > this.length) {
        return false;
    }

    for (var i = 0, n = 0; i < this.length; i++) {
        if (this[i] != this[dx]) {
            this[n++] = this[i];
        }
    }
    this.length -= 1;
};
/**
 * 将html文本中的标签去掉，只留下文字
 */
function getHTMLClearTxt(str) {

    str = str.replace(/<\/?[^>]*>/g, ''); //去除HTML tag
    str = str.replace(/[ | ]*\n/g, '\n'); //去除行尾空白
    //str = str.replace(/\n[\s| | ]*\r/g,'\n'); //去除多余空行
    str = str.replace(/&nbsp;/ig, '');//去掉&nbsp;
    str = str.replace(/\s/g, ''); //将空格去掉
    return str;
}

/**
 * 打电话
 */
function callPhone(phoneNum) {
    window.location.href = 'tel://' + phoneNum;
}

/**
 * 本窗口打开连接
 */
function openUrl(url) {
    window.location.href = url;
}

/**
 * 新建窗口打开连接
 */
function openUrlBlank(url) {
    window.open(url, "_blank"); //注意第二个参数
}

/**
 * 页面返回
 */
function goBack() {
    history.back();
}

/**
 * 控件隐藏
 * @param(name) 控件id
 */
function hideName(name) {
    $("#" + name).css("display","none");// hide();
}

/**
 * 控件展示
 * @param(name) 控件id
 */
function showName(name) {
    $("#" + name).css("display","block");//.show();
}

/**
 * 页面重新展示时候刷新
 */
function seRefreshOnShow() {
    window.addEventListener('pageshow', function (e) {
        if (e.persisted) {
            window.location.reload();
        }
    });
}

/**
 * 刷新页面
 * @returns {number}
 */
function refreshLocalView() {
    window.location.reload();
}

/**
 * 获取屏幕宽度
 * @returns {number}
 */
function getWindowWidth() {
    return document.documentElement.clientWidth;
}

/**
 * 获取屏幕高度
 * @returns {number}
 */
function getWindowHeight() {
    return document.documentElement.clientHeight;
}

/**
 * 获取当前链接
 */
function getCurrentHref() {
    return window.location.href;
}
/**
 * 获取本连接中的参数
 * @param name 参数名称
 * @returns {*}
 * @constructor
 */
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}

/**
 * 模型转json
 * @param model
 * @returns {string}
 */
function  jsonToStr(model) {
    if (model == null) return null;
    if (typeof (model) == 'string') return model;
    return JSON.stringify(model);
}

/**
 * 将json字符串转成对象
 * @param str
 * @returns 模型
 */
function jsonToModel(str) {
    var model = str;
    if (typeof (str) == 'string') {
        str = str.replaceAll("\n","\\n");
        str = str.replaceAll("\r","\\r");
        model = JSON.parse(str);
    }
    return model;
}

/**
 * 手机的一些信息
 */
var LLPhoneInfor = {
    versions: function () {
        var u = navigator.userAgent, app = navigator.appVersion;
        return {//移动终端浏览器版本信息
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //Opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果/谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //iOS终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //Android终端或者UC浏览器
            iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1 //是否Web应该程序，没有头部与底部
        };
    }(),
    //是否是在微信环境
    isInWeixin: function () {
        var ut = navigator.userAgent.toLowerCase();
        return (ut.match(/MicroMessenger/i) == "micromessenger");
    }()
};


/**
 * 判断是否是图片
 * @param src 图片base64后的字符串
 * @returns {boolean}
 */
function checkImg(imgData) {
    return imgData.indexOf("data:image/") > -1;
}
function checkInputImg(input) {
    var filePath = input.value;
    var exten = filePath.substring(filePath.lastIndexOf(".") + 1, filePath.length);
    exten = exten.toLowerCase();
    if (exten=="jpg" ||exten=="png" ||exten=="jpeg" ||exten=="gif"){
        return true;
    }
    return false;
}
/**
 * 判断是否是视频
 * @param src 图片base64后的字符串
 * @returns {boolean}
 */
function checkVideo(videoData) {
    return videoData.indexOf("data:video/") > -1;
}
function checkInputVideo(input) {

    var filePath = input.value;
    var exten = filePath.substring(filePath.lastIndexOf(".") + 1, filePath.length);
    exten = exten.toLowerCase();
    if (exten=="mp4"){
        return true;
    }
    return false;
}

/**
 * 通过连接获取base64编码的字符串
 * @param imgUrl
 * @param resultFunc 图片获取之后的返回方法，参数为base64编码字符串，过滤掉逗号前面部分
 */
function getImgBase64Str(imgUrl,resultFunc) {
    var img = new Image;
    img.crossOrigin = 'Anonymous';
    img.src = imgUrl;
    img.onload = function(){
        appRoutes.loge(3);
        if (resultFunc != null){
            appRoutes.loge(4);
            var base64 =  getBase64Image(img);
            appRoutes.loge(base64);
           resultFunc(base64);
        }
    };

}

/**
 * 通过img标签获取图片的base64编码字符串
 * @param img js标签对象
 * @returns {string} 返回结果为base64编码字符串，已经过滤掉逗号前面部分
 */
function getBase64Image(img) {
    var canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;

    var ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, img.width, img.height);

    var dataURL = canvas.toDataURL("image/png");
    // return dataURL
    return dataURL.replace("data:image/png;base64,", "");
}

/**
 * 压缩图片尺寸
 * @param imgData base64后的图片字符串
 * @param maxW
 * @param maxH
 */
function compressImg(imgData, maxW, maxH) {
    if (checkImg(imgData) == false) return null;

    var myImage = new Image();
    myImage.src = imgData;    //背景图片  你自己本地的图片或者在线图片
    myImage.crossOrigin = 'Anonymous';

    var imgW = myImage.width;
    var imgH = myImage.height;
    var scale = 1;
    if (imgW / maxW > imgH / maxH) {
        scale = maxW / imgW;
    } else {
        scale = maxH / imgH;
    }
    var canvas = document.createElement("canvas");
    canvas.width = imgW / scale;
    canvas.height = imgH / scale;
    var context = canvas.getContext("2d");

    context.rect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#fff";
    context.fill();

    context.drawImage(myImage, 0, 0, 700, 700);
    var base64 = canvas.toDataURL("image/png");
    return base64;
}

/**
 * 画图
 * @param imgView
 * @param userIcon
 * @param userName
 */
function drawAndShareImage(imgView, userIcon, userName) {
    var canvas = document.createElement("canvas");
    canvas.width = 700;
    canvas.height = 700;
    var context = canvas.getContext("2d");

    context.rect(0, 0, canvas.width, canvas.height);
    context.fillStyle = "#fff";
    context.fill();

    var myImage = new Image();
    myImage.src = "./2.png";    //背景图片  你自己本地的图片或者在线图片
    myImage.crossOrigin = 'Anonymous';

    myImage.onload = function () {
        context.drawImage(myImage, 0, 0, 700, 700);

        context.font = "60px Courier New";
        context.fillText("我是文字", 350, 450);

        var myImage2 = new Image();
        myImage2.src = "./1.png";   //你自己本地的图片或者在线图片
        myImage2.crossOrigin = 'Anonymous';

        myImage2.onload = function () {
            context.drawImage(myImage2, 175, 175, 225, 225);
            var base64 = canvas.toDataURL("image/png");  //"image/png" 这里注意一下
            var img = document.getElementById('avatar');

            // document.getElementById('avatar').src = base64;
            img.setAttribute('src', base64);
        }
    }
}

/**
 * 获取元素距离body顶部距离
 * @param el
 * @returns {*}
 */
function getElementTop (el) {
    var actualTop = el.offsetTop;
    var current = el.offsetParent;
    while (current !== null) {
        actualTop += current.offsetTop;
        current = current.offsetParent;
    }
    return actualTop;
}

/**
 * 页面滚动，懒加载图片
 */
function setWindowLazyLoadImg() {
    var func = function () {
        // 获取高度
        var h = window.innerHeight;
        // 获取滚动条的位置 也就是当前屏幕的位置
        var t = document.documentElement.scrollTop || document.body.scrollTop;

        // 当前屏幕的高度 + 滚动条的位置 = 当前屏幕的位置 (可视区域) t + h
        var num = t + h;

        //获取图片
        var imgList = document.querySelectorAll("img");
        for (var i = 0; i < imgList.length; i++){
            var img = imgList[i];
            var src = img.getAttribute("src");
            var dataSrc = img.getAttribute("data-src");
            if (src == null || src.length == 0 && dataSrc != null) {

                var top = getElementTop(img);
                if (top <= num) {
                    var image = new Image();
                    image.onload = function () {
                        img.src = dataSrc;
                    };
                    image.src = dataSrc;
                }
            }
        }
    };
    window.addEventListener("scroll",func);
    setTimeout(func,200);
}

/**
 * 页面滚动，懒加载图片
 */
function setElementLazyLoadImg(parentId,defaultSrcUrlOrContain) {
    var parentView = document.getElementById(parentId);

    var func = function () {
        // 获取高度
        var h = parentView.clientHeight;
        // 获取滚动条的位置 也就是当前屏幕的位置
        var t = parentView.scrollTop;

        // 当前屏幕的高度 + 滚动条的位置 = 当前屏幕的位置 (可视区域) t + h
        var num = t + h;

        //获取图片
        var imgList = parentView.getElementsByTagName("img");
        for (var i = 0; i < imgList.length; i++){
            let imgEle = imgList[i];

            let src = imgEle.getAttribute("src");
            let dataSrc = imgEle.getAttribute("data-src");
            if ((src == null || src.length == 0 || src.indexOf(defaultSrcUrlOrContain) > -1) && dataSrc != null) {
                var top = imgEle.offsetTop;
                var imgHeight = imgEle.clientHeight;
                if ((top <= num && top >= t) || (top + imgHeight <= num && top + imgHeight >= t)) {
                    var image = new Image();
                    image.onload = function () {
                        imgEle.src = dataSrc;// setAttribute("src",dataSrc);
                    };
                    image.src = dataSrc;
                }
            }
        }
    };
    parentView.addEventListener("scroll",func);
    setTimeout(func,100);
}



var ptLocalStorage = {
    /**
     * 页面共享给其他页面数据
     * @param key
     * @param jsonData
     */
    setData: function (key, jsonData) {
        // 存储
        window.localStorage.setItem(key, jsonData);
    },

    /**
     * 获取页面共享的缓存数据
     * @param key
     */
    getData: function (key) {
        // 读取
        var tempData = window.localStorage.getItem(key);
        return tempData;
    },

    /**
     * 删除页面共享的缓存数据
     * @param key
     */
    deleteData: function (key) {
        //删除
        window.localStorage.removeItem(key);
    },

    /**
     * 清除页面缓存数据
     */
    clearData: function () {
        window.localStorage.clear();//清空所有的存储数据
    }
};
var ptSessionStorage = {
    /**
     * 页面共享给其他页面数据
     * @param key
     * @param jsonData
     */
    setData: function (key, jsonData) {
        // 存储
        window.sessionStorage.setItem(key, jsonData);
    },

    /**
     * 获取页面共享的缓存数据
     * @param key
     */
    getData: function (key) {
        // 读取
        var tempData = window.sessionStorage.getItem(key);
        return tempData;
    },

    /**
     * 删除页面共享的缓存数据
     * @param key
     */
    deleteData: function (key) {
        //删除
        window.sessionStorage.removeItem(key);
    },

    /**
     * 清除页面缓存数据
     */
    clearData: function () {
        window.sessionStorage.clear();//清空所有的存储数据
    }
};

/**
 * 监听页面滚动到底部
 * @param func
 */
function listenScrollToBottom(func) {
    //获取滚动条当前的位置
    let getScrollTop = function () {
        var scrollTop = 0;
        if (document.documentElement && document.documentElement.scrollTop) {
            scrollTop = document.documentElement.scrollTop;
        }
        else if (document.body) {
            scrollTop = document.body.scrollTop;
        }
        return scrollTop;
    }

    //获取当前可是范围的高度
    let getClientHeight = function() {
        var clientHeight = 0;
        if (document.body.clientHeight && document.documentElement.clientHeight) {
            clientHeight = Math.min(document.body.clientHeight, document.documentElement.clientHeight);
        }
        else {
            clientHeight = Math.max(document.body.clientHeight, document.documentElement.clientHeight);
        }
        return clientHeight;
    }

    //获取文档完整的高度
    let getScrollHeight = function() {
        return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    }
    window.onscroll = function () {
        if (getScrollTop() + getClientHeight() == getScrollHeight()) {
            if (func!= null){
                func();
            }
        }
    }
}

function createClass(styleText) {
    var nod = document.createElement("style");
    // styleText = "body{background:#000;color:#fff} a{color:#fff;text-decoration:none;} a:hover{color:red;text-decoration:underline}";
    nod.type="text/css";
    if(nod.styleSheet){         //ie下
        nod.styleSheet.cssText = styleText;
    } else {
        nod.innerHTML = styleText;       //或者写成 nod.appendChild(document.createTextNode(str))
    }
    document.getElementsByTagName("head")[0].appendChild(nod);
}