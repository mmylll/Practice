var isDebug = true;//是否是本地测试环境
/**
 * 网络请求
 * @param url
 * @param params
 * @param successFunc
 * @param failFunc
 */
function netUtils(url, params, successFunc, failFunc) {
    var data = {
        "data": JSON.stringify(params)
    };
    // netLog("url = " + url + "\n params = \n" + JSON.stringify(data));
    $.ajax({
        //请求方式
        type: "POST",
        data: data,
        //请求的媒体类型
        // contentType: "charset=UTF-8",
        dataType: "json",
        //请求地 址
        url: url,
        //请求成功
        success: function (result) {
            // netLog(JSON.stringify(result));
            if (successFunc != null) {
                successFunc(result);
            }
            //alert(result);
        },
        //请求失败，包含具体的错误信息
        error: function (e) {
            if (failFunc != null) {
                failFunc(e);
            }
            // netLog(e.responseText);
        }
    });
}

function netUtilsNotAsync(url, params, successFunc, failFunc) {
    var data = {
        "data": JSON.stringify(params)
    };
    netLog("url = " + url + "\n params = \n" + JSON.stringify(data));

    $.ajax({
        //请求方式
        type: "POST",
        async: false,
        data: data,
        //请求的媒体类型
        // contentType: "charset=UTF-8",
        dataType: "json",
        //请求地 址
        url: url,
        //请求成功
        success: function (result) {


            netLog(result);
            if (successFunc != null) {
                successFunc(result);
            }
            //alert(result);
        },
        //请求失败，包含具体的错误信息
        error: function (e) {
            if (failFunc != null) {
                failFunc(e);
            }
            netLog(e.responseText);
        }
    });
}

/**
 * 上传文件
 * @param inputEle js原生标签的对象
 * @param url 请求地址（后半段）
 * @param params 参数 {}
 * @param progressFunc 上传进度回调，int值，最大100
 * @param successFunc 成功回调
 * @param failedFunc 失败回调
 */
function netPostFile(inputEle, url, params, progressFunc, successFunc, failedFunc) {
    //获取到选中的文件
    var file = inputEle.files[0];
    //创建formdata对象
    var formdata = new FormData();
    formdata.append("file", file);
    if (params != null) {
        for (key in params) {
            formdata.append(key, params[key]);
        }
    }
    //创建xhr，使用ajax进行文件上传
    var xhr = new XMLHttpRequest();

    //post方式，url为服务器请求地址，true 该参数规定请求是否异步处理。
    xhr.open("post", url, true);
    //回调
    xhr.onreadystatechange = function () {
        netLog(xhr.responseText);
        if (xhr.readyState == 4 && xhr.status == 200) {
            if (successFunc != null) {
                successFunc(xhr.responseText);
            }
        } else {
            if (failedFunc != null) {
                failedFunc(xhr.responseText);
            }
        }
    }
    //获取上传的进度
    xhr.upload.onprogress = function (event) {
        if (event.lengthComputable) {
            var percent = event.loaded / event.total * 100;
            netLog(percent + "%");
            if (progressFunc != null) {
                progressFunc(percent);
            }
        }
    }
    //将formdata上传
    xhr.send(formdata);
}

function netLog(str) {
    if (str != null && isDebug){
        console.log(str);
    }
}
