/**
 * 带标题、内容、确定按钮、取消按钮的弹框
 * @param show 是否显示弹框
 * @param tag 这个弹框的标示
 * @param title 标题
 * @param content 内容
 * @param btns [{title:'确定',color:'#333333'}]
 * v-on:lldialogclick(index) 按钮点击事件回调
 */
//显示图片的弹框
Vue.component('ll-dialog', {
    props: ['show','tag','title', 'content','btns'],
    template: "<div v-show='show' style='position: fixed;z-index: 10000;top: 0px;left: 0px;right: 0px;bottom: 0px;background-color: rgba(0,0,0,0.5)' >" +
        "<div style='width: 300px;position: absolute;left: 0px;right: 0px;margin:-100px auto auto auto;background-color: white;top:50%;border-radius: 5px;'>"
        + "<div style='width: 100%;line-height: 40px;text-align: center;color: #333;font-size: 15px;'>{{title}}</div>"
        + "<div style='width: 100%;padding-left: 10px;padding-right: 10px;margin-top: 10px;box-sizing: border-box;font-size: 14px;color: #666;' v-html='content'></div>"
        + "<div style='width: 100%;height: 40px;margin-top: 10px;position:relative;text-align: center;line-height: 40px;font-size: 16px;border-top: 1px solid #ccc;'>"
        + "<div v-for='(item,index) in btns' style='display:inline-block;height: 100%;' @click='dialogClick(index)' :style='{width:btnWidth,color:item.color!=null?item.color:\"#333333\"}'>{{item.title}}</div>"
        + "<div v-for='(item,index) in btns' v-if='index<btns.length-1' style='position:absolute;top: 0px;bottom: 0px;width: 1px;backgroundColor: #999999;' :style='{left:btnWidth}'></div>"
        + "</div>"
        + "</div>"
        + "</div>",
    data: function(){
        return {

        }
    },
    computed:{
        btnWidth:function () {
            return (100 / this.btns.length - 0.5) + "%";
        }
    },
    methods:{
        dialogClick: function (index) {
            this.$emit('lldialogclick',index);
        },


    }
})


/**
 * 删除标签
 * @param name 标签id
 */
function removeDialog(eleId) {
    var ele = document.getElementById(eleId);
    ele.parentElement.removeChild(ele);
}

//显示图片的弹框
Vue.component('show-img-diloag', {
    props: ['dialogTitle', 'imgSrc'],
    template:
        '<div class="fulled" style="font-size: 20px !important;">' +
        '<div id="delAreaDiv" class="fix-box" style="width: 800px;position: fixed;top: 50px;bottom: 50px;left: 0px;right: 0px;margin: auto;">' +
        '<div style="height: 35px;    background-color: #dcdcdc; border: 3px solid   #dcdcdc; line-height: 35px;">' +
        '<span style="float: left;margin-left: 10px;     font-size: 20px;    font-weight: bold;">{{dialogTitle}}</span>' +
        '<div style="float: right;   font-size: 30px; line-height: 30px; border: none;margin-right: 10px;" @click="$emit(\'close-img-dialog\')">x</div>' +
        '</div>' +
        '<div>' +
        '<div style="position:absolute; text-align: center;width: 100%;box-sizing: border-box;overflow: scroll;top: 40px;bottom: 0px;padding: 5px;" class="verticalCenter">' +
        '<img style="max-width: 100%;max-height: 100%;" :src="imgSrc">' +
        '</div>' +
        '</div>' +
        ' </div>' +
        '</div>',

});


//iframe弹框
Vue.component('show-iframe-diloag', {
    props: ['dialogTitle', 'iframeUrl'],
    template:
        '<div class="fulled" style="font-size: 20px !important;">' +
        '<div id="delAreaDiv" class="fix-box" style="width: 1000px;position: fixed;top: 50px;bottom: 50px;left: 0px;right: 0px;margin: auto;">' +
        '<div style="height: 35px;    background-color: #dcdcdc; border: 3px solid   #dcdcdc; line-height: 35px;">' +
        '<span style="float: left;margin-left: 10px;     font-size: 20px;    font-weight: bold;">{{dialogTitle}}</span>' +
        '<div style="float: right;   font-size: 30px; line-height: 30px; border: none;margin-right: 10px;" @click="$emit(\'close-iframe-dialog\')">x</div>' +
        '</div>' +
        '<div style="position:absolute; text-align: center;width: 100%;box-sizing: border-box;overflow: scroll;top: 40px;bottom: 0px;padding: 5px;" class="verticalCenter">' +
        '<iframe id="iFrame1" name="iFrame1" style="width: 100%;height: 100%;" frameborder="0" :src="iframeUrl"></iframe>' +
        '</div>' +
        ' </div>' +
        '</div>'

});