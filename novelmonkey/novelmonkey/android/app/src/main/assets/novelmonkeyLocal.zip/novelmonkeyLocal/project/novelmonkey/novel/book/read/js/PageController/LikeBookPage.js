/**
 * 仿真翻页功能
 * @param chapter0 上一章节信息
 * @param chapter1 当前章节信息
 * @param chapter2 下一章节信息
 * @param needGoNextPageCallBack 需要上翻时调用，参数bool值，是否急需
 * @param needGoPreviousCallBack 需要下翻时调用，参数bool值，是否急需
 */
function PTLikeBookControll(chapter0, chapter1, chapter2, needGoPreviousCallBack, needGoNextPageCallBack) {
    var _lastChapterInfo = chapter0;
    var _currentChapterInfo = chapter1;
    var _nextChapterInfo = chapter2;
    _initChapterInfos();

    if (_lastChapterInfo != null) {
        _initChapterView(_lastChapterInfo.chapterId, _lastChapterInfo.currentPageIndex);
    }

    if (_currentChapterInfo != null) {
        _initChapterView(_currentChapterInfo.chapterId, _currentChapterInfo.currentPageIndex);
    }

    if (_nextChapterInfo != null) {
        _initChapterView(_nextChapterInfo.chapterId, _nextChapterInfo.currentPageIndex);
    }

    //到上一页面
    this.goLast = function () {
        if (_currentChapterInfo.currentPageIndex == 1) {
            //如果上一章节有数据，并且上一章节index比当前章节index小1，说明上一章节信息正确  将上一章设置为当前文章
            if (_lastChapterInfo != null && _lastChapterInfo.chapterIndex + 1 == _currentChapterInfo.chapterIndex) {

                var last = _lastChapterInfo;
                _lastChapterInfo = _nextChapterInfo;
                _nextChapterInfo = _currentChapterInfo;
                _currentChapterInfo = last;

                bodyData.chapterInfos.lastChapter = _lastChapterInfo;
                bodyData.chapterInfos.currentChapter = _currentChapterInfo;
                bodyData.chapterInfos.nextChapter = _nextChapterInfo;
                bodyData.currentChapterIndex = _currentChapterInfo.chapterIndex;



                _resetLastChapterCurrentPageToEnd();
                _resetChapterViewZIndex();

                //将上一章节设置为当前章节后，索要上一章节信息
                if (needGoPreviousCallBack != null) {
                    needGoPreviousCallBack(false);
                }
            } else {
                if (needGoPreviousCallBack != null) {
                    needGoPreviousCallBack(true);
                }
            }
        }
        if (_currentChapterInfo.currentPageIndex > 1) {
            //到第一页了，
            $("#" + _currentChapterInfo.chapterId).turn("previous");
            _currentChapterInfo.currentPageIndex--;

            if (_currentChapterInfo.currentPageIndex == 1) {
                //到第一页了，
                if (needGoPreviousCallBack != null) {
                    needGoPreviousCallBack(false);
                }
            }
        }
    };

    //到下一页面
    this.goNext = function () {
        if (_currentChapterInfo.currentPageIndex >= _currentChapterInfo.pages.length) {
            if (_currentChapterInfo.currentPageIndex == _currentChapterInfo.pages.length) {
                bodyData.goNextChapter();
                return;

                if (bodyData.wantToGoNextChapter() == false)return;

                if (_nextChapterInfo != null && _nextChapterInfo.chapterIndex - 1 == _currentChapterInfo.chapterIndex) {
                    //如果下一章的章节index没错，翻页后，交换数据模型


                    $("#" + _currentChapterInfo.chapterId).turn("next");
                    _currentChapterInfo.currentPageIndex++;
                    //到最后一页，并且下一章数据已经加载好了
                    var last = _lastChapterInfo;
                    _lastChapterInfo = _currentChapterInfo;
                    _currentChapterInfo = _nextChapterInfo;
                    _nextChapterInfo = last;

                    bodyData.chapterInfos.lastChapter = _lastChapterInfo;
                    bodyData.chapterInfos.currentChapter = _currentChapterInfo;
                    bodyData.chapterInfos.nextChapter = _nextChapterInfo;
                    bodyData.currentChapterIndex = _currentChapterInfo.chapterIndex;


                    bodyData.didSwipToNextChapter();

                    _resetChapterViewZIndex();

                    //要下一章的内容
                    if (needGoNextPageCallBack != null) {
                        needGoNextPageCallBack(false);
                    }
                } else {
                    //下一章数据有问题，即没有下一章，直接要下一章并返回，
                    if (needGoNextPageCallBack != null) {
                        needGoNextPageCallBack(true);
                    }
                }
            } else {
                //没有下一章，直接要下一章并返回，
                if (needGoNextPageCallBack != null) {
                    needGoNextPageCallBack(true);
                }
            }
        } else {
            //没有最后一页，可以正常翻页
            $("#" + _currentChapterInfo.chapterId).turn("next");
            _currentChapterInfo.currentPageIndex++;
        }
    };

    //设置页码到哪个页面
    this.setCurrentPage = function (pageIndex) {
        if (pageIndex > _currentChapterInfo.pages.length){
            pageIndex = _currentChapterInfo.pages.length;
        }
        $("#" + _currentChapterInfo.chapterId).turn("page", pageIndex).turn("stop");

        _currentChapterInfo.currentPageIndex = pageIndex;
    };

    /**
     * 获取数据
     * @param index
     * @return {*}
     */
    this.getChapterInfo = function (index) {
        switch (index) {
            case 0: {
                return _lastChapterInfo;
            }
            case 1: {
                return _currentChapterInfo;
            }
            case 2: {
                return _nextChapterInfo;
            }
        }
    };
    /**
     * 获取数据
     * @param index
     * @return {*}
     */
    this.setChapterInfo = function (index, info) {
        switch (index) {
            case 0: {
                _lastChapterInfo = info;
            }
                break;
            case 1: {
                _currentChapterInfo = info;
            }
                break;
            case 2: {
                _nextChapterInfo = info;
            }
                break;
        }
        if (info) {
            info.currentPageIndex = index == 0 ? info.pages.length + 1 : (index == 2 ? 1 : info.currentPageIndex);
            _initChapterView(info.chapterId, info.currentPageIndex);
            _resetChapterViewZIndex();

            _resetLastChapterCurrentPageToEnd();

        }

    };

    /**
     * 对象初始化
     * @private
     */
    function _initChapterInfos() {
        //设置初始页面
        if (_lastChapterInfo != null) _lastChapterInfo.currentPageIndex = _lastChapterInfo.pages.length + 1;
        if (_currentChapterInfo != null) _currentChapterInfo.currentPageIndex = _currentChapterInfo.currentPageIndex == 0 ? 1 : _currentChapterInfo.currentPageIndex;
        if (_nextChapterInfo != null) _nextChapterInfo.currentPageIndex = 1;

        _resetChapterViewZIndex();
    }

    /**
     * 初始化翻页工具
     * @private
     */
    function _initChapterView(chapterId, pageIndex) {
        pageIndex = pageIndex > 0 ? pageIndex : 1;
        $("#" + chapterId).turn({
            duration:200,
            acceleration: true,//设置硬件加速模式，对于触摸设备，此值必须为真。
            page: pageIndex,//初始页面
            autoCenter: true,//中心翻取决于有多少页面可见 true or false
            gradients:true,
            display: "single",//设置是双页面还是单页面,默认双页面
        });
        $("#" + chapterId).bind("start",function(event,pageobject,corner){
            if (pageobject.page == _currentChapterInfo.pages.length) {
                if (corner == "br"||corner == "tr"){
                    event.preventDefault();
                }
            } else{
                if (corner == "br"||corner == "tr"){//下一页
                    llApi.monkey_analysis("reader_nextpage_tap")
                } else{//上一页
                    llApi.monkey_analysis("reader_lastpage_tap")
                }
            }
            // if(corner=="tl"||corner=="tr"){
            //     event.preventDefault();
            // }
        });
        document.getElementById(chapterId).style.position = "absolute";


    }

    //将上一章节滚动到最后一页
    function _resetLastChapterCurrentPageToEnd() {
        if (_lastChapterInfo != null){
            $("#" + _lastChapterInfo.chapterId).turn("page", _lastChapterInfo.pages.length + 1).turn("stop");
        }
    }


    /**
     * 重置文章的层级关系
     * @private
     */
    function _resetChapterViewZIndex() {
        if (_lastChapterInfo != null) {
            var lastChapterView = document.getElementById(_lastChapterInfo.chapterId);
            if (lastChapterView != null) {
                lastChapterView.style.top = "0px";
                lastChapterView.style.left = "0px";
                lastChapterView.style.display = "none";
            }
        }
        if (_currentChapterInfo != null) {
            var currentChapterView = document.getElementById(_currentChapterInfo.chapterId);
            if (currentChapterView != null) {
                currentChapterView.style.top = "0px";
                currentChapterView.style.left = "0px";
                currentChapterView.style.display = "block";
            }


            var _lastProgress = 0;
            $("#" + _currentChapterInfo.chapterId).bind("turned",function(event,page,view){
                //设置当前页码
                _currentChapterInfo.currentPageIndex = page;

                /**
                 * 阅读进度统计
                 * @type {number}
                 */
                var progress = page * 1.0 / _currentChapterInfo.pages.length;


                if (progress > _lastProgress && _lastProgress <= 1) {

                    progress = Math.floor(progress / 0.2) * 0.2;
                    if (progress == _lastProgress)return;

                    _lastProgress = progress;
                    if (progress > 1){
                        progress = 1;
                    }

                    llApi.monkey_analysis("chapter_read_progress",
                        {
                            book_id: bodyData.bookDetail.bookId,
                            chapter_id: bodyData.chapterListInfo.chapterTBList[_currentChapterInfo.chapterIndex].chapterId,
                            progress: progress
                        });

                }
            })

        }

        if (_nextChapterInfo != null) {
            var nextChapterView = document.getElementById(_nextChapterInfo.chapterId);

            if (nextChapterView != null){
                nextChapterView.style.top = "0px";
                nextChapterView.style.left = "0px";
                nextChapterView.style.display = "none";
            }
        }

    }
}