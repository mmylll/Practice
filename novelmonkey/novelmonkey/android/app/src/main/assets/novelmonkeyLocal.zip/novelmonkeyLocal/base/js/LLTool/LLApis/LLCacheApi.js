(function () {
    llApi[""]
        /**
         * 加载网络图片
         * @param imgUrl
         * @param func回调函数 参loadNetImgData数：imgUrl图片原链接，imgData本地下载后的base64图片
         */
        llApi["loadCacheNetImgData"] = function () {
            setTimeout(function () {
                let imgList = document.querySelectorAll("img");

                for (let i = 0; i < imgList.length; i++) {
                    let imgView = imgList[i];
                    let url = imgView.getAttribute("data-src");
                    let src = imgView.getAttribute("src");

                    //
                    if (url != null && url.length > 0 && (src==null || src.length == 0 || src.indexOf("./") > -1 || src.indexOf("http") > -1)) {
                        if (llCacheNetImgData[url] != null) {
                            imgView.src = llCacheNetImgData[url]
                        } else {
                            llApi.loadNetImgData(url, function (imgData) {
                                llCacheNetImgData[url] = imgData;
                                imgView.src = imgData
                            });
                        }

                    }
                }
            }, 100);
        };
        /**
         * 缓存数据
         * @param key 键
         * @param model 数据模型
         */
        llApi["cacheData"] = function (key, model) {
            if (key == null || typeof(key) != "string") return;
            let params = {
                key: key
            };
            if (model != null) {
                let json = llJsonToStr(model);
                params.data = json;
            }
            let paramsStr = llJsonToStr(params);
            llPerformSelectAction("cacheData", paramsStr, null);
        };

        /**
         * 缓存数据
         * @param key 键
         * @param func 返回数据，参数为数据模型
         */
        llApi["getCacheData"] = function (key, func) {
            if (key == null || typeof(key) != "string") {
                if (func != null) {
                    func(null);
                }
                return;
            }
            llPerformSelectAction("getCacheData", key, func);
        };
})();

/**
 * 数据缓存时常用的key
 */
let llCacheDataKeys = {
    userData:"userData",//缓存用户信息的key
    systemConfig:"systemConfig",//系统配置
};
/**
 * 缓存的图片信息
 * @type {{}}
 */
llCacheNetImgData = {};