(function () {
    let url = window.location.href;
    let leftPath = url.split("project")[0];
    document.write("<script language=javascript src='" + leftPath + "project/novelmonkey/js/ApiUtils.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "project/novelmonkey/js/AppRoutes.js" + "'></script>");
    document.write("<script language=javascript src='" + leftPath + "project/novelmonkey/js/ProjectApi.js" + "'></script>");
    document.write("<link rel='stylesheet' href='" + leftPath + "project/novelmonkey/css/project_base.css?v=1'>");
})();




/**
app配置信息
 */
const appConstInfo = {
    novel_img_height_width_scale : 1.4,//海报列表中图片的宽高比例

    banner_width_height_scale:1.7,//banner图片宽高比例

    /**
     * 默认头像
     * @param sex 1男 2女
     */
    default_user_icon: function (sex) {
        var resultPath = getProjectFile(sex == 1 ? "imgs/sex_male.png" : "imgs/sex_female.png");
        return resultPath;
    },
    /**
     * 获取虚拟币的名称
     */
    _virtalCashName:"",
    getVirtalCashName: function (func) {
        if (appConstInfo._virtalCashName.length > 0){
            if (func != null){
                func(appConstInfo._virtalCashName);
            } 
            return;
        }
        
        llApi.getCacheData(llCacheDataKeys.systemConfig,function (data) {
            var result = "书币";
            if (data != null){
                for (let i = 0; i < data.length; i++) {
                    var item = data[i];
                    if (item.configKey == "virtalCashName"){
                        appConstInfo._virtalCashName = item.jsonData;
                        result = appConstInfo._virtalCashName;
                    }
                }   
            }
            if (func != null){
                func(result);
            }
        });
    }
};

/**
 * 获取数量
 */
function getCharSize(count) {
    if (count < 1000){
        return count;
    }
    if (count < 1000 * 1000){
        return parseInt(count / 100) / 10 + "千";
    }
    if (count < 1000 * 1000 * 1000){
        return parseInt(count / (1000 * 100)) / 10 + "万";
    }
    if (count < 1000 * 1000 * 1000 * 10000){
        return parseInt(count / (1000 * 1000 * 1000)) / 10 + "亿";
    }
    return count;
}